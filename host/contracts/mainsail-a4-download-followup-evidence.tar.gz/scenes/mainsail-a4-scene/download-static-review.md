# 下载失败只读调查

本场 Mainsail 菜单下载 guid `5907724b-2aad-448b-99a4-a2a5789be01e` 在 1792073394013 开始，7ms 后为 `canceled`，receivedBytes=0、totalBytes=944；本机下载目录为空。该失败独立保留，不算通过。

目前没有足够证据归因产品。根已核 gateway 保留 content-disposition/content-length、流式 pipeline；本场只保存下载状态，没有 Network.loadingFailed 的原始错误，因此不能从 canceled 单独确定文件权限、浏览器策略、客户端取消或连接中断。

## 已查静态事实

- 本机安装 Playwright1.62.1 的 `playwright-core/lib/coreBundle.js:42835–42877` 为 connectOverCDP 建立默认 artifacts/downloads 路径；51135–51144 默认 acceptDownloads=accept；38324–38330 发送 allowAndName。
- 本场随后通过独立CDP会话改为 `Browser.setDownloadBehavior {behavior:'allow',downloadPath:本场/downloads,eventsEnabled:true}`。这让 Playwright 的内部 uuid/artifact 路径与自定义目录/建议文件名不一致；51808–51819 的 Artifact 仍绑定内部downloadsPath+uuid。此事实足以解释“Playwright事件/文件路径 API 与实际保存目录可能不一致”，但尚不能解释 Chromium 自己发出的 canceled，不能把它称为根因。
- 38234–38251 仅将浏览器的canceled转为Download失败；38512–38516 中主动取消走 Browser.cancelDownload。本场脚本没有调用 download.cancel，也没有在下载时关闭context。
- 本场在点击Download后，同一工具调用立即点击Machine导航。尚未保留下载终态就切换页面，存在路由/iframe生命周期影响的假设；没有捕获相关加载失败，当前仅是假设。原Fluidd相似调度也不构成因果证明。
- 只读查询本场自有私有profile的History：downloads表0条，指定guid无记录；仅保存这一计数，不复制数据库/浏览历史。它没有提供interrupt_reason。
- 特定注册表值查询：HKCU Edge policy根不存在；HKLM根存在，但DownloadRestrictions、DownloadDirectory、PromptForDownloadLocation、SmartScreenEnabled四值均未出现。这不能排除其他浏览器/云策略或扩展影响。没有修改设置。

## 建议的一次有界判别（待审，未运行）

独立Node loopback服务提供同一944字节/SHA9107b8…合成文件，明确Content-Disposition attachment和Content-Length；静态页面只有一个可见下载链接。固定同一Edge可执行文件／默认sandbox／Playwright1.62.1／独立临时profile／相同CDP下载设置，只点击一次链接，等待终态前不导航、不关闭页面。

总60秒含启动清理，下载等待最多10秒；记录命令顺序、浏览器download事件、Playwright failure、Network.loadingFailed及允许的响应长度/类型/Disposition、实际文件字节SHA。无打印产品、MCU、登录或真实设备，不禁用任何浏览器安全策略。

- 若同样canceled：说明失败可脱离打印产品发生，下一步应查工具/浏览器/写入层；仍不证明具体原因。
- 若completed且文件SHA相同：只证明最小浏览器下载链可用；Mainsail/client/gateway与过早导航差异仍待新的有区分力观察，不把独立附件通过写成Mainsail通过。
- 保留本场所有失败；不重开Mainsail场、不自动追加第二次下载或改变安全/产品设置。

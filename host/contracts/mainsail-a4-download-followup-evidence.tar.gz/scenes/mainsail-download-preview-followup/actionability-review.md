# Download actionability follow-up: observed facts and missing observation

This is a read-only interpretation of the existing600-second scene, not another run. Source435938218, productcd91/deps0b530 unchanged. Both real chooser uploads returned201. No PRINT/home/config/queue/fault mutation was submitted.

Observed tool traces (existing tool IDs):
- node_repl initial G-CODE FILES exact-role lookup exceeded30s; kernel reset. Same private browser was reconnected.
- original-browser thumbnail/name actions produced a Start Job confirmation and transient Download menu text. Confirmations were cancelled. No PRINT submitted.
- screenshot tool waited for fonts, then page.screenshot timed out4000ms. Therefore no screenshot success at this step.
- subsequent getByText Download resolved role=menuitem/id=list-item-1272, but actionability trace repeatedly said element is not visible. It did not click; no download event was obtained. A visible-menu observation in a prior call cannot establish visibility during the later click.
- original Edge135308 was actually absent and CDP19236 had no listener at1792075395012 (exec436415). An earlier node_repl error said target page/context/browser closed. No exit-code/native-crash/cleanup callback evidence was collected; cannot assign this to Edge crash, Playwright cleanup, product, or OS.
- parent approved one same-scene reconstruction; Edge80568 reused original private profile and uploaded files, keeping original absolute deadline.
- its navigation link rectangle was x=-220,y144,width220,right0: an actually offscreen drawer, matching outside-viewport trace. Actual nav-icon click later moved link to x0,y200,width220,height48. Click stability waits still failed. A normal visible coordinate click at100,224 reached the files list.
- row hover trace reached visible/stable, scrolled, then timed out during performing hover. td action cell remained empty. No contemporaneous overlay/hit-test/process-CPU/frame trace was captured, so obstruction cause is unknown.

Interpretation: at least one navigation timeout has directly observed offscreen-drawer geometry. The Download timeout itself observed a hidden menuitem; prior transient visibility and print-confirmation presence are insufficient to decide whether a popup transition, menu closure, overlay, tool lifecycle, or another factor caused hiding. There was no actual terminal menu download in this follow-up. Independent default-PW synthetic download success does not replace the missing Mainsail action.

No DOM mutation, force click, injected fetch, API mutation, security changes or extra scene was used. At480021ms the original owned watchdog signalled root SIGTERM; root/gateway cleanup completed with exit0, all registered Linux children joined. Windows cleanup verified at591396ms, within600000ms. Preserve earlier failing browser downloads and setup failures. Next work must stay with current candidate/performance and same-package Mainsail gaps; no peripheral component or additional sample is implied by this review.
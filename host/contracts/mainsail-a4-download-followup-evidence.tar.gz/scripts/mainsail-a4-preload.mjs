import {readFile,writeFile,open} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
const out='/home/dek02/.codex/worktrees/supervisor-group-compat/evidence/client-external-fault',started=Date.now(),deadline=started+900000;
const runner=out+'/client-fault-runner-scene.ts';if(process.argv[1]!==runner||process.argv[2]!=='mainsail'||createHash('sha256').update(await readFile(runner)).digest('hex')!=='3ea68a718b2f2a4b813063913dcdccc0017f578c59708500b60d2f6af197cca2')throw Error('Expected frozen Mainsail runner');
const raw=await readFile('/proc/self/stat','utf8'),startTicks=raw.slice(raw.lastIndexOf(')')+2).split(' ')[19],log=await open(out+'/mainsail-a4-watchdog.log','wx');
const watchdog=spawn(process.execPath,[out+'/mainsail-a4-watchdog.mjs',String(process.pid),startTicks,String(deadline),out+'/mainsail-a4-watchdog.json'],{stdio:['ignore',log.fd,log.fd],detached:true});watchdog.unref();await log.close();
const receipt={event:'bounded-scene-launch',pid:process.pid,startTicks,watchdogPid:watchdog.pid,started,deadline,stopNewActionsAt:deadline-120000};await writeFile(out+'/mainsail-a4-running.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));

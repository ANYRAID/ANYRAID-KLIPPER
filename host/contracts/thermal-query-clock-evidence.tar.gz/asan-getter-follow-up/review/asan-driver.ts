import {spawnSync} from 'node:child_process';
import {existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
const host=fileURLToPath(new URL('..',new URL('file:///home/dek02/.codex/worktrees/supervisor-group-compat/toolhead-clock-diagnostic-source/host/scripts/test-native-sanitized.ts')));
const input=process.argv.slice(2),listing=input[0]==='--list';
if(listing)input.shift();
if(input.length>1||input.length===1&&!['--mode=ubsan','--mode=asan'].includes(input[0]))throw new Error('Usage: test-native-sanitized.ts [--list] [--mode=ubsan|--mode=asan]');
const modes=input.length?[input[0]==='--mode=asan']:[false,true];
const commands:string[][]=[];
function run(args:string[],env:NodeJS.ProcessEnv=process.env):void {
  if(listing){commands.push(args);return;}
  const started=performance.now();
  const result=spawnSync(process.execPath,args,{cwd:host,stdio:'inherit',timeout:60000,env});
  console.log(JSON.stringify({sanitizedCommand:args,elapsedMs:performance.now()-started,status:result.status,signal:result.signal}));
  if(result.status!==0)throw new Error(`Sanitized check failed: ${result.error??result.status}; signal=${result.signal??'none'}; command=${JSON.stringify(args)}`);
}
const lookup=listing?undefined:spawnSync(process.env.CC??'cc',['-print-file-name=libasan.so'],{encoding:'utf8'});
const runtime=lookup?.stdout.trim()??'';
if(!listing&&(lookup?.status!==0||!existsSync(runtime)))throw new Error('Compiler AddressSanitizer runtime was not found');
for(const address of modes) {
  const flag=address?'--address':'--sanitize',suffix=address?'asan':'ubsan';
  const env:NodeJS.ProcessEnv={...process.env,
    ANYRAID_FILE_EVENTS_ADDON:fileURLToPath(new URL(`../build/file-events-${suffix}.node`,new URL('file:///home/dek02/.codex/worktrees/supervisor-group-compat/toolhead-clock-diagnostic-source/host/scripts/test-native-sanitized.ts'))),
    ANYRAID_AR100_TEST_ADDON:fileURLToPath(new URL(`../build/ar100-flash-test-${suffix}.node`,new URL('file:///home/dek02/.codex/worktrees/supervisor-group-compat/toolhead-clock-diagnostic-source/host/scripts/test-native-sanitized.ts'))),
    ANYRAID_CAN_QUERY_ADDON:fileURLToPath(new URL(`../build/can-query-${suffix}.node`,new URL('file:///home/dek02/.codex/worktrees/supervisor-group-compat/toolhead-clock-diagnostic-source/host/scripts/test-native-sanitized.ts'))),
    ANYRAID_SEALED_FILE_ADDON:fileURLToPath(new URL(`../build/sealed-file-${suffix}.node`,new URL('file:///home/dek02/.codex/worktrees/supervisor-group-compat/toolhead-clock-diagnostic-source/host/scripts/test-native-sanitized.ts'))),
    ANYRAID_UNIX_PEER_ADDON:fileURLToPath(new URL(`../build/unix-peer-${suffix}.node`,new URL('file:///home/dek02/.codex/worktrees/supervisor-group-compat/toolhead-clock-diagnostic-source/host/scripts/test-native-sanitized.ts'))),
    ANYRAID_SERIALQUEUE_ADDON:fileURLToPath(new URL(`../build/serialqueue-${suffix}.node`,new URL('file:///home/dek02/.codex/worktrees/supervisor-group-compat/toolhead-clock-diagnostic-source/host/scripts/test-native-sanitized.ts'))),
    ANYRAID_TRAPQ_ADDON:fileURLToPath(new URL(`../build/trapq-${suffix}.node`,new URL('file:///home/dek02/.codex/worktrees/supervisor-group-compat/toolhead-clock-diagnostic-source/host/scripts/test-native-sanitized.ts'))),
    ANYRAID_STEPCOMPRESS_ADDON:fileURLToPath(new URL(`../build/stepcompress-${suffix}.node`,new URL('file:///home/dek02/.codex/worktrees/supervisor-group-compat/toolhead-clock-diagnostic-source/host/scripts/test-native-sanitized.ts'))),
  };
  if(address) {
    env.LD_PRELOAD=[runtime,process.env.LD_PRELOAD].filter(Boolean).join(':');
    // Node/V8 owns uninstrumented process-global allocations: check access and
    // lifetime errors, without claiming process-wide leak accounting.
    env.ASAN_OPTIONS='detect_leaks=0:abort_on_error=1';
  }

  env.ANYRAID_FILE_WRITE_LEASE_HELPER=fileURLToPath(new URL(`../build/file-write-lease-${suffix}`,new URL('file:///home/dek02/.codex/worktrees/supervisor-group-compat/toolhead-clock-diagnostic-source/host/scripts/test-native-sanitized.ts')));
  run(['--test','--test-reporter=tap','test/product-service.test.ts'],env);
  run(['--test','--test-reporter=tap','test/async-heater-runtime.test.ts'],env);
}

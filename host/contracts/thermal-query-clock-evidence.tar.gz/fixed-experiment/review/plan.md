# 固定热时钟估计语义单轮验证（未执行）

主例只采用8次warmup再开heater：F=1e6/origin0/sent10；i1..8的MCU=i*1e6，sent10+i，receive10+i+.002，warmup=true。第九次MCU8999995/sent19/receive19.002，warmup=false。查询19.0019999→19.002，均递增；计数亦递增，误差仅-5ticks，远低500us门槛。无参数扫描。

独立期望来自EW加权回归：令D=30^9，w0=29^9、wi=29^(9-i)*30^(i-1)，计算Sx/Sy/Sxx/Sxy；frequency=(D*Sxy-Sx*Sy)/(D*Sxx-Sx²)。旧模型query值9000999.9取整9000999；新模型在19.002约9000998.455892589取整9000998。固定期望不依赖ClockSync自身输出来生成；实际binary64若偏离，保留失败不改样本。此数学样本不是原CI未保存的四值。

脚本仅导入实际ClockSync、AsyncHeaterRuntime、BangBangControl及其纯值依赖，无自定义native addon、串口/MCU/设备或真实热输出。模拟reset/stop立即确认，target0、一条合法25°C样本，无PWM写。clock适配器记录每次原返回，不修改任何guard。

一次进程内两个固定控制分支：A启动于18.002，sample后在19.0019999调用getTemperature，再接收更新并于19.002调用getter，预期原Invalid thermal clock、独立stop确认。B同样输入但无前一高频getter，只从18.002到19.002手动触发原一秒保护tick，预期active（print仍高于startup heartbeat、sample新鲜）。B不等于证明HeaterPWM任何更新都安全；不删除/绕过它的严格heartbeat检查。每个实例均最终shutdown/确认stop，无后台定时器。

使用已登记同asset Node26.12与现隔离源码，先核script和三直接源SHA；GNU timeout --signal=TERM --kill-after=2s 15s，20s绝对取证界；单次、不重试，不改JIT/算法/阈值/保护，无构建或20项重跑。记录Node及直接timeout PID/ticks、原始stdout/stderr和退出，结束独立核两PID已退场；本脚本不创建子进程。固定1735只读、不触碰。仅用于证实源码估计语义，不解释原CI或184硬件。

根审后再执行；当前仅准备，无产品/测试提交或推送。
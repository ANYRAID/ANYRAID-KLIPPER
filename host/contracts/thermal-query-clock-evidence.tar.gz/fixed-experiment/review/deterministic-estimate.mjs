import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
const source='/home/dek02/.codex/worktrees/supervisor-group-compat/toolhead-clock-diagnostic-source';
const {ClockSync}=await import(pathToFileURL(source+'/host/src/timing/clock-sync.ts').href);
const {AsyncHeaterRuntime}=await import(pathToFileURL(source+'/host/src/thermal/async-runtime.ts').href);
const {BangBangControl}=await import(pathToFileURL(source+'/host/src/thermal/control.ts').href);
const frequency=1000000,warmup=Array.from({length:8},(_,i)=>({clock32:(i+1)*frequency,sentTime:11+i,receiveTime:11+i+.002})),correction={clock32:8999995,sentTime:19,receiveTime:19.002},queryBefore=19.0019999,queryAfter=19.002;
function identity(pid){const raw=fs.readFileSync('/proc/'+pid+'/stat','utf8'),f=raw.slice(raw.lastIndexOf(')')+2).split(' ');return {pid,startTicks:f[19],ppid:Number(f[1]),pgrp:Number(f[2])};}
async function run(getterBefore){
 const sync=new ClockSync(frequency,0n,10),releases=warmup.map(sample=>sync.accept(sample,true));assert(releases.every(v=>v!==null));
 let now=18.002,tick=()=>{},resets=0,stops=0,writes=0,cancels=0;const clockReads=[];
 const clock=()=>{const ticks=sync.getClock(now),value={system:now,print:Number(ticks)/frequency};clockReads.push({...value,ticks:ticks.toString(),revision:sync.revision});return value;};
 const output={configuration:{cycleTime:.1,maximumDuration:3,defaultPower:0,initialPower:0},async reset(){resets++;},async setPWM(){writes++;},async stop(){stops++;}};
 const runtime=new AsyncHeaterRuntime({minimum:0,maximum:300,minimumExtrude:170,smoothTime:1,maxPower:1,reportDelay:.3},new BangBangControl(1),output,clock,{},callback=>{tick=callback;return()=>{cancels++;};});
 await runtime.start();const sampleTime=Number(sync.getClock(now))/frequency;runtime.sample(sampleTime,25);
 now=queryBefore;const before=sync.getClock(now);assert.equal(before,9000999n);if(getterBefore){const status=runtime.getTemperature();assert.equal(status.stale,false);}
 const accepted=sync.accept(correction);assert.notEqual(accepted,null);assert.equal(sync.lastClock,8999995n);assert.equal(sync.active,true);
 now=queryAfter;const after=sync.getClock(now);assert.equal(after,9000998n);assert(queryAfter>queryBefore&&after<before);
 let failure;if(getterBefore){try{runtime.getTemperature();}catch(error){failure=error;}assert(failure instanceof Error);assert.equal(failure.message,'Invalid thermal clock');assert.equal(runtime.status.cause,failure);assert.equal(stops,1);}
 else{tick();assert.equal(runtime.status.phase,'active');assert.equal(runtime.status.cause,undefined);assert.equal(stops,0);}
 const beforeCleanup={...runtime.status},activityBeforeCleanup={resets,stops,writes,cancels};assert.equal(writes,0);assert(Number(after)/frequency>sampleTime);
 await runtime.shutdown();assert.equal(runtime.status.phase,'stopped');assert.equal(stops,1);assert.equal(cancels,1);
 return {path:getterBefore?'high_frequency_getTemperature':'one_second_protection_tick_without_prior_getter',before:before.toString(),after:after.toString(),deltaTicks:(after-before).toString(),estimate:sync.estimate,sampleTime,clockReads,beforeCleanup,activityBeforeCleanup,failure,finalPhase:runtime.status.phase};
}
const result={startedUtc:new Date().toISOString(),self:identity(process.pid),timeoutParent:identity(process.ppid),node:process.version,sourceHashes:Object.fromEntries(['host/src/timing/clock-sync.ts','host/src/thermal/async-runtime.ts','host/src/thermal/control.ts'].map(p=>[p,crypto.createHash('sha256').update(fs.readFileSync(source+'/'+p)).digest('hex')])),input:{frequency,uptimeClock:'0',initialSent:10,warmup,correction,queryBefore,queryAfter,expectedBefore:'9000999',expectedAfter:'9000998'},cases:[]};
try{result.cases.push(await run(true));result.cases.push(await run(false));result.status='fixed_semantic_counterexample_confirmed';}catch(error){result.status='single_failure_preserved_no_retry';result.error=error;process.exitCode=1;}
result.endedUtc=new Date().toISOString();console.log(JSON.stringify(result,(_key,v)=>v instanceof Error?{name:v.name,message:v.message,stack:v.stack,cause:v.cause}:typeof v==='bigint'?v.toString():v,2));
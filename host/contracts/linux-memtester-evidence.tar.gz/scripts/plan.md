# 独立memtester：准备中，未执行负载

工具来自现有APT community-packages.deepin.com/beige crimson/community，索引Trusted yes且无trusted/allow-insecure/allow-unauthenticated绕过；不apt update。固定memtester4.6.0-1 amd64包18872bytes，SHAa5c2ba34256c86882b4fab1b01f22e36b63c2f0ea241d41c06a3ad291be2f37e。下载后先核SHA、列检16个普通data目录/文件无链接或越界，再dpkg-deb --extract至本任务unpacked，只data不执行维护脚本。解包C binary27176bytes/SHA2c10853878d7a1bf659f2b1d29c301f864b8da66255b729ea5d46c74ffa3f66b。依赖仅libc.so.6/GLIBC>=2.34，当前2.38；binary/包留184缓存，不作为产品依赖或Git二进制。

已读随包man、README、README.tests、BUGS。普通模式malloc申请，失败能自动缩小；mlock失败会警告且继续。文档虽建议root，现有普通用户RLIMIT_MEMLOCK=2087563264足够256MiB，只使用现有限制，不sudo/提权/ulimit/sysctl。只允许精确命令`unpacked/usr/sbin/memtester 256M 1`，不-p/-d、不触碰/dev/mem或任何物理映射。默认未指定次数为无限，故固定1；MEMTESTER_TEST_MASK会跳测试，任意MEMTESTER_*或原生loader/allocator覆盖存在即停，不静默清除。

预注册256MiB=268435456bytes、默认完整集合一pass。静态binary/包内测试说明核Stuck Address加17个测试名，包括8/16-bit Writes；不改mask/缩集。没有文档保证耗时，不先试跑估时。采用既有900s总上限：owner780s TERM C、795s直子KILL；外部既有GNUtimeout9.4于870s TERM整个独立进程组、15s后KILL，留下900s内取证空间。它是上限而非完成耗时承诺，超时保留未完成，不减小内存/跳测试/重跑求绿。

`launch-once.sh`仅一次外封装：`/usr/bin/timeout --signal=TERM --kill-after=15s --verbose 870s <fixed Node26.11.1> owner.mjs`。不--foreground，Node owner和直接C子继承timeout同进程组；owner校验父guard实际exe/SHA/完整登记参数及pgrp，并记录owner/guard/wrapper/C PID和startTicks。外timeout独立于Node记录owner，保护Node异常或挂起时的C后代；owner自身仍是Node，真正内存测试路径为独立C binary，不把此称完全无Node设施。

运行前核包/C/timeout/Node/libc/loader与脚本SHA；保留普通uid、未改限制、MEMTESTER/loader环境名称为空、当前MemAvailable至少1GiB安全余量，并拒绝同任务memtester/同项目Node/Rust/GCC负载。新out`/home/dek02/.codex/worktrees/supervisor-group-compat/evidence/memtester-once`存在即拒绝；旧诊断与产品不修改。资源复用已审串行1s采样，额外只读C/proc/status的VmLck，读取后仍核startTicks。采样1024行/32MiB；原始两流各4MiB，backspace原样保留，另作终端式规范化，超限/设施失败明确停并不计完整。

完整判据必须同时满足：无receipt.error、实际时间<=900s；C code0/signull；原输出want及每次got均精确268435456；出现locked；本场实际C VmLck>=262144KiB；仅Loop1、Done和18项均ok；无停止原因/日志截断/资源失败且子已消失。锁输出出现时主动采一次，不暂停进程凑证据；若过快而VmLck采不到则证据不足。实际缩水或锁失败立即保留并停，不能凭exit0称原计划完成。发现测试错误不自动新开pass，最多保留这一固定pass至自然退出/原限时/日志上限。

C退出bits独立解释：1分配/锁/调用，2 Stuck Address，4其他测试，可能OR组合；单独保存实际signal。外timeout返回124超时、125设施、126不可执行、127不存在、137KILL，与Node owner的汇总代码和C bitmask分开，不把timeout124按memtester bits解释。正常完成后亦需独立核wrapper/timeout/owner/C登记身份消失，保持原始输出和资源前后；没有receipt也不重启。

解释范围：阳性支持独立C用户分配内存测试路径出现问题，不等于定位RAM条/CPU/电源或排除工具/运行库问题。阴性只覆盖本次256MiB虚拟分配一pass，不能排除间歇故障或认证全RAM。原11/16/14/G3、motion捕获与原归档均不改。当前仅取得/静态读取工具并准备脚本，没有运行memtester；待根审具体SHA和命令后才启动唯一场。

#!/bin/sh
set -u
review=/home/dek02/.codex/worktrees/supervisor-group-compat/evidence/memtester-review
out=/home/dek02/.codex/worktrees/supervisor-group-compat/evidence/memtester-once
test ! -e "$out" || exit 90
test ! -e "$review/timeout-result.json" || exit 91
/usr/bin/timeout --signal=TERM --kill-after=15s --verbose 870s /home/dek02/.cache/codex/tmp/legacy-install-oct14/node26.11.1/node-v26.11.1-linux-x64/bin/node "$review/owner.mjs" > "$review/owner.stdout.log" 2> "$review/timeout.stderr.log"
code=$?
printf '{"timeoutExitCode":%s,"endedMs":%s,"wrapperPid":%s,"scope":"Outer timeout status, not memtester exit bits"}\n' "$code" "$(date +%s%3N)" "$$" > "$review/timeout-result.json"
exit "$code"

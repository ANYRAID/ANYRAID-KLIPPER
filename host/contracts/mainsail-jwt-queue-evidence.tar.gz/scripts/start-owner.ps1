$ErrorActionPreference='Stop'
$dir=Join-Path (Get-Location) '.cache/client-fault-validation/mainsail-jwt-queue-review'
$runner='C:/Devs/Codex/from-184/.cache/codex/tmp/anyraid-moonraker-composition-integration/host/acceptance/client-fault-runner.ts'
if((Get-FileHash -LiteralPath $runner -Algorithm SHA256).Hash.ToLowerInvariant() -ne '3ea68a718b2f2a4b813063913dcdccc0017f578c59708500b60d2f6af197cca2'){throw 'Registered synthetic runner changed'}
if(Test-Path (Join-Path (Get-Location) '.cache/client-fault-validation/mainsail-jwt-queue-once')){throw 'N scene path already exists'}
if($env:ANYRAID_SCENE_USERNAME -or $env:ANYRAID_SCENE_PASSWORD){throw 'Unexpected existing N account environment'}
$accountPattern=[regex]::Escape("JSON.stringify({username:'")+"([^']+)"+[regex]::Escape("',password:'")+"([^']+)"+[regex]::Escape("'})")
$accountMatches=[regex]::Matches([IO.File]::ReadAllText($runner),$accountPattern)
if($accountMatches.Count -ne 1){throw 'Registered synthetic account expression not unique'}
$syntheticAccount=$accountMatches[0]
try{
 $env:ANYRAID_SCENE_USERNAME=$syntheticAccount.Groups[1].Value
 $env:ANYRAID_SCENE_PASSWORD=$syntheticAccount.Groups[2].Value
 $node=Join-Path (Get-Location) '.cache/supervisor-windows-validation/node-v26.9.0-win-x64/node.exe'
 $p=Start-Process -FilePath $node -ArgumentList (Join-Path $dir 'owner.cjs') -WorkingDirectory (Get-Location) -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $dir 'owner.stdout.log') -RedirectStandardError (Join-Path $dir 'owner.stderr.log')
 $identity=@{pid=$p.Id;startTicks=$p.StartTime.Ticks.ToString()}
 [IO.File]::WriteAllText((Join-Path $dir 'owner-launch.json'),($identity|ConvertTo-Json -Compress),[Text.UTF8Encoding]::new($false))
 $identity|ConvertTo-Json -Compress
}finally{Remove-Item Env:ANYRAID_SCENE_USERNAME,Env:ANYRAID_SCENE_PASSWORD -ErrorAction SilentlyContinue;$syntheticAccount=$accountMatches=$null}

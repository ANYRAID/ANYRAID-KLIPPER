; ANYRAID synthetic PTY-only lifecycle distinct short job
G90
G92 E0
G1 X2 Y1 E0.05 F600
G1 X4 Y2 E0.1 F600
M400

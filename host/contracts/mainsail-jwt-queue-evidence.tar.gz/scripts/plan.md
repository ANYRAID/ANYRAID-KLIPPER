# 当前1735队列／Pause Resume／显式清台唯一有限场

- 固定173565dc／0b53079c、Mainsail2.19.0和JWT gateway，184双PTY；仅CLOSE stdin。禁止cancel/restart/firmware restart/fault、电源或实际设备操作。不重复下载、预览、配置维护。
- 必要chooser只上传已核长42065字节(dc2886e1…)和短113字节(1e17d97c…)；长只允许一次直接Print，短只允许本场队列确认触发。长理论运动约200秒，预留菜单／暂停恢复及收口；不加新延时或改产品状态。
- 复用旧成功证据mainsail-a4-scene/business-ws.jsonl、06-paused-queue.json、08-before-clearance.json及产品queue页面；不把旧cd91证据冒充本次1735通过。
- 原生JWT登录→Files chooser→Dashboard一次ALL/G28→长filename／Print→只读等真实printing（preparing不通过）→before-queue检查点。
- 忙时右击短filename→真实Add to Queue→busy-queued检查点必须仍printing；Dashboard原生Pause→paused检查点→实际观察Resume按钮后点击→resumed及resumed-progress，同job/request保持、自然进度增加。Pause/Resume各一次。
- 长自然completed后completed-hold-a与completed-hold-b两检查点间隔至少5秒，均旧job completed/history1、queue paused/head短、无transition、无新job或prepare/confirm请求。
- 点击主文档已观察的打印队列链接，到精确/_client/queue。该页面没有Mainsail iframe，observe只读主文档；所有后续target必须surface=page，不能复用旧frame。现场inspect后点击#queue-prepare，记录实际POST仅{request_confirmation:true}形状。
- confirmation-ready检查点必须仍只有旧completed job、queue paused/head短且awaiting_confirmation，随后实际点击#queue-cleared，读取checked=true及confirm已使能，再点#queue-confirm。记录实际POST仅transition_token字段形状和SHA摘要，不存原值、cookie或其他凭据。
- 等不同短job/request completed。最终history恰两条completed、队列空且paused、直接long-start/G28/queue-add/Pause/Resume各1。prepare、confirmation-ready、confirm和所有业务／检查点严格单调；产品PID/startTicks、generation1在全场保持。
- 九检查点固定顺序，业务前后均有只读状态及实页观察。关键Pause/恢复推进/等待清台/确认就绪/短完成截图缺失单列，不称完整视读通过。任何业务断言失败立即有界清理，不自动重开。
- 独立out mainsail-jwt-queue-once；原独立owner和Windows/Linux watchdog不改780秒拒绝新动作、870秒强制、900秒绝对收口。正常结束立即清理并核PID/端口/两守卫，不等截止。
- 复用N-diag唯一注册Mainsail iframe、pages/frameID/opener/error观察；新页仅观察不自动选。根审helper／owner.patch／输入和SHA之后才启动本场。

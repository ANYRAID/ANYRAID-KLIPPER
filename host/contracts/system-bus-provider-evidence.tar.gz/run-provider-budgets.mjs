import {spawnSync} from 'node:child_process';
import {writeFileSync,readFileSync,existsSync} from 'node:fs';
import assert from 'node:assert/strict';
const root='/home/dek02/.cache/codex/tmp/legacy-install-oct14/dbus-preflight',controls=[],comparisons=[];
assert.equal(process.version,'v26.11.1');assert.equal(process.env.NODE_OPTIONS,undefined);
for(const [pair,order] of [['before','after'],['after','before'],['before','after']].entries()){
 const sets={};
 for(const label of order){
  sets[label]={auth:{}};
  for(const [kind,routes] of [['auth',['status','file','image','anonymous-image']],['network',['original']],['uploads',['original']]])for(const route of routes){
   const name=pair+'-'+kind+'-'+route+'-'+label;assert(!existsSync(root+'/bench/'+name+'.status'),'Fresh budget run refuses an existing result: '+name);let result;
   {
    result=spawnSync(process.execPath,[root+'/bench/'+kind+'-'+label+'.mjs'],{encoding:'utf8',timeout:60000,maxBuffer:4*1024**2,env:{...process.env,TMPDIR:'/home/dek02/.cache/codex/tmp',ANYRAID_AUTH_BENCH_ROUTE:route==='original'?undefined:route}});
    writeFileSync(root+'/bench/'+name+'.json',result.stdout,{flag:'wx'});writeFileSync(root+'/bench/'+name+'.stderr',result.stderr,{flag:'wx'});writeFileSync(root+'/bench/'+name+'.status',JSON.stringify({status:result.status,signal:result.signal,error:result.error?.message})+'\n',{flag:'wx'});assert.equal(result.status,0,name);assert.equal(result.error,undefined,name);
   }
   const record=JSON.parse(result.stdout);if(kind==='auth')sets[label].auth[route]=record;else sets[label][kind]=record;controls.push({pair,kind,route,label,name,reused:false,record});
  }
 }
 for(const route of ['status','file','image','anonymous-image']){const before=sets.before.auth[route],after=sets.after.auth[route],ratio=after.medianMs/before.medianMs;comparisons.push({pair,kind:'auth',route,before:before.medianMs,after:after.medianMs,ratio,limit:1.5,absoluteUs:after.microsecondsPerRequest,maximumUs:10,pass:ratio<=1.5&&after.microsecondsPerRequest<10});}
 for(const mode of ['manual','configured'])for(const kind of ['http','ws','startup']){const before=sets.before.network.results[mode][kind],after=sets.after.network.results[mode][kind],ratio=after.medianMs/before.medianMs;comparisons.push({pair,kind:'network',route:mode+'/'+kind,before:before.medianMs,after:after.medianMs,ratio,limit:1.5,pass:ratio<=1.5});}
 for(const [i,after] of sets.after.uploads.results.entries())for(const mode of ['direct','http']){const before=sets.before.uploads.results[i];assert.equal(after.size,before.size);const ratio=after.results[mode].medianMs/before.results[mode].medianMs;comparisons.push({pair,kind:'uploads',size:after.size,mode,before:before.results[mode],after:after.results[mode],ratio,limit:1.5,pass:ratio<=1.5});}
 console.log(JSON.stringify({pair,comparisons:comparisons.length,maxRatio:Math.max(...comparisons.filter(r=>r.pair===pair).map(r=>r.ratio)),pass:comparisons.filter(r=>r.pair===pair).every(r=>r.pass)}));
}
const summary={schema:1,node:process.version,controls,comparisons,pass:comparisons.every(c=>c.pass),scope:'Original auth100000x8, configured HTTP200/WS500/startup30 with 3warm11samples, uploads4/16MiB2warm7. Sequential fresh AB/BA/AB using previous accepted 704-file fixed-Node installation product before and newly rebuilt 723-file D-Bus candidate after; symmetric none source for configured network, actual private-default D-Bus startup measured separately; no overlapping task benchmarks or mixed scenes. No old successful welcome baseline; no Python or board throughput claim.'};writeFileSync(root+'/budgets.json',JSON.stringify(summary,null,2)+'\n',{flag:'wx'});if(!summary.pass)process.exitCode=1;

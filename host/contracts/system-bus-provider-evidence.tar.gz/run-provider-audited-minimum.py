import json,os,subprocess,pathlib,time,re
r=pathlib.Path("/home/dek02/.cache/codex/tmp/legacy-install-oct14/dbus-preflight");repo=pathlib.Path("/home/dek02/.cache/codex/tmp/anyraid-moonraker-composition-integration/host");files=json.loads((r/"provider-compiled-selection.json").read_text())["core"]["source"]
for f in files:assert pathlib.Path(f).is_file(),f
node="/home/dek02/.codex/worktrees/e068/ANYRAID-KLIPPER/host/node_modules/.cache/node26/node-v26.9.0-linux-x64/bin/node"
name="provider-audited-core-minimum";env=dict(os.environ,TMPDIR="/home/dek02/.cache/codex/tmp");start=time.monotonic()
with (r/(name+".log")).open("w") as log:result=subprocess.run([node,"--test","--test-isolation=none","--test-reporter=tap",*files],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
(r/(name+".status")).write_text(str(result.returncode)+"\n");text=(r/(name+".log")).read_text();counts={k:int(re.findall(r"^# "+k+r" (\d+)$",text,re.M)[-1]) for k in ["tests","pass","fail","cancelled","skipped","todo"]};(r/(name+".json")).write_text(json.dumps(dict(node=node,files=files,counts=counts,durationSeconds=time.monotonic()-start,status=result.returncode),indent=2)+"\n");print(counts,flush=True);assert result.returncode==0 and counts["tests"]==counts["pass"]==73 and all(counts[k]==0 for k in ["fail","cancelled","skipped","todo"])

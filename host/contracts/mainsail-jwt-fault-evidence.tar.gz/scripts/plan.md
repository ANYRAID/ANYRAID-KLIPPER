# 当前1735外部故障恢复唯一有限场（准备稿，尚未启动）

- 固定173565dc／0b53079c、Mainsail2.19.0、JWT gateway及双PTY；使用未改client-fault-runner.ts（SHA3ea68a71…）。仅复用长42065字节及短113字节输入，不重复文件维护或队列场，不改产品。
- 复用已审N-diag owner的自然页面操作、唯一注册iframe、pages/frame/error只读观察与双端watchdog。独立mainsail-jwt-fault-once：780秒拒绝新动作、870秒强制清理、900秒绝对截止；首业务失败收口，不自动重开。截图缺失单列，关键图须根视读。
- JWT真实登录→chooser仅上传这两个输入→原生ALL/G28→只直接Print长文件一次。只读确认printing、旧job/request、history1/in_progress和进度后记录before-fault。
- owner仅各发送一次ARM、CRASH；CRASH后必须等待固定runner已joined的external-product-close（旧PID、code:null、signal:SIGKILL、simulationClosed:true、requestsJoined:true）。保存Connection failed实际页面及offline只读GET实际状态；若502未实测，不补写。未显式RECOVER前不得出现新产品PID或新的start。
- 仅在joined SIGKILL且offline后一次RECOVER。保持原gateway／浏览器。新产品PID/startTicks与旧身份不同、runner会话generation2；新产品内部device generation从1开始。原生TRY AGAIN显式重连，等待真实新WS握手与页面；记录recovered-interrupted：旧job/request不变、history1/interrupted、无新任务/重放。此状态是恢复启动后的耐久调和结果，不声称离线时已读到磁盘interrupted。
- 原生可见Firmware Restart一次，记录printer.firmware_restart；核耐久operation succeeded、旧job cancelled、idle／request null／unhomed，新产品PID不变且内部device generation1→2。不把它代替前场已验标准RESTART或直接Cancel。
- 再原生ALL/G28→不同短文件Print一次→只读等completed，旧job仍cancelled、history恰2、短job/request均不同。原生Clear print stats只一次，实际printer.gcode.script仅SDCARD_RESET_FILE；核idle／request null且两条history保留。
- 六检查点按单调时间固定为before-fault、offline、recovered-interrupted、firmware-recovered、short-complete、stats-cleared。只读poll先确认，再落一次检查点；不按固定短sleep假定状态。业务RPC仅G28两次、print.start长短各一次、firmware_restart一次、SDCARD_RESET_FILE一次；不允许Pause/Resume/Cancel/标准Restart/队列/电源等额外变更。
- preload分别以wx保留product-1.json／product-2.json，记录精确PID/startTicks及相同隔离root/profile，gateway仅一次；不覆盖旧身份。owner remoteOwned登记两代产品，cleanup核两者／root／gateway／guard都离场；Linuxguard沿用100ms子孙census。原固定runner日志保留CLIENT_GENERATION与product-ready／explicit-process-recovery，分别解释设备和会话计数。
- 新页只采必要安全origin/path/opener，不读取非任务DOM、不自动选页；沿已观察p1／唯一Mainsail iframe。凭据仅运行内存，归档无profile、DB、原始cookie／token／账号口令。正常完成立即CLOSE并有界清理，核Windows精确拥有进程及两端端口／guard终态。
- 旧cd91 mainsail-firmware-scene的614.838秒流程仅作复用来源，不计当前1735通过。后续收尾逐行核现有A4九项映射，保留全A集成／性能／G3等独立开放门槛。

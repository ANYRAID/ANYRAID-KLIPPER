param([int]$Sequence,[ValidateSet('observe','inspect_target','checkpoint','fault_command','read_state','fill','click','scroll','keyboard','chooser','checkpoint_files','download','append_config','verify_config','preview_checkpoint','finish')][string]$Op,[string]$Label,[int]$Observation=-1,[ValidateSet('page','mainsail')][string]$Surface='mainsail',[string]$Css,[string]$Role,[string]$Name,[ValidateSet('username','password')][string]$Field,[ValidateSet('submit-login','config-save','config-reopen')][string]$Intent,[ValidateSet('right')][string]$Button,[string[]]$Keys,[string[]]$Files,[ValidateSet('ARM','CRASH','RECOVER')][string]$RunnerCommand)
$ErrorActionPreference='Stop'
$scene=Join-Path (Get-Location) '.cache/client-fault-validation/mainsail-jwt-fault-once'
$command=@{sequence=$Sequence;op=$Op;label=$Label}
if($Observation -ge 0){$command.observation=$Observation}
if($Css){$command.target=@{surface=$Surface;css=$Css}}
if($Role){$command.target=@{surface=$Surface;role=$Role;name=$Name;exact=$true}}
if($Field){$command.field=$Field}
if($Intent){$command.intent=$Intent}
if($Button){$command.button=$Button}
if($Keys){$command.keys=$Keys}
if($Files){$command.files=$Files}
if($RunnerCommand){$command.runnerCommand=$RunnerCommand}
$stem='cmd-'+$Sequence.ToString('0000')
$temporary=Join-Path $scene ('commands/'+$stem+'.tmp')
$destination=Join-Path $scene ('commands/'+$stem+'.json')
if(Test-Path ($destination+'.consumed')){throw 'Command already consumed'}
[IO.File]::WriteAllText($temporary,($command|ConvertTo-Json -Depth 6 -Compress),[Text.UTF8Encoding]::new($false))
Move-Item -LiteralPath $temporary -Destination $destination
$resultPath=Join-Path $scene ('results/'+$stem+'.json')
$until=[DateTime]::UtcNow.AddSeconds(40)
while(!(Test-Path $resultPath) -and !(Test-Path (Join-Path $scene 'receipt.json')) -and [DateTime]::UtcNow -lt $until){Start-Sleep -Milliseconds 100}
if(!(Test-Path $resultPath)){if(Test-Path (Join-Path $scene 'receipt.json')){Get-Content (Join-Path $scene 'receipt.json')};throw 'No successful owner command result'}
$result=Get-Content -Raw $resultPath|ConvertFrom-Json -Depth 30
if($result.result.id){@{id=$result.result.id;page=$result.result.page;mainsail=$result.result.mainsail;screenshotCaptured=$result.result.screenshotCaptured;browser=$result.result.browser;diagnostics=$result.result.diagnostics}|ConvertTo-Json -Depth 8 -Compress}
else{$result.result|ConvertTo-Json -Depth 30 -Compress}

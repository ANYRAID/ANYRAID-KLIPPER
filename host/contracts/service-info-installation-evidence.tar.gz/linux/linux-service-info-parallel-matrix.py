from pathlib import Path
import json,hashlib,subprocess,os,time,shutil
base=Path('/home/dek02/.codex/worktrees/supervisor-group-compat');root=base/'ANYRAID-KLIPPER';ev=base/'evidence/service-info';app=base/'service-info-parallel-product';independent=base/'service-info-parallel-independent';actual=base/'service-info-parallel-product-tests'
node='/home/dek02/.cache/codex/tmp/legacy-install-oct14/node26.11.1/node-v26.11.1-linux-x64/bin/node';minimum=str(base/'node26.9/node-v26.9.0-linux-x64/bin/node')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
freeze=json.loads((ev/'service-info-source-freeze-parallel.json').read_text());assert all(sha(root/r['path'])==r['sha256'] for r in freeze['files'])
inputs=json.loads((ev/'none-unchanged-motion-inputs.json').read_text());assert all(sha(root/r['path'])==r['sha256'] for r in inputs['files']);native=json.loads((app/'host/build/native-build-info.json').read_text());assert all(sha(root/p)==h for p,h in native['sources'].items());assert all(sha(app/'host/build'/p)==h for p,h in native['outputs'].items())
(ev/'linux-parallel-frozen-identities.json').write_text(json.dumps({'sourceFiles':freeze,'motionAndPackage':inputs,'nativeReuse':{'metadata':native,'inputsMatched':len(native['sources']),'outputsMatched':len(native['outputs']),'source':'Prior controlled Linux build retained by none-product; not rebuilt in this batch'},'node':{'current':{'path':node,'sha256':sha(node)},'minimum':{'path':minimum,'sha256':sha(minimum)}}},indent=2))
identity=json.loads((ev/'linux-product-parallel-identity.json').read_text());assert sha(app/'build-info.json')==identity['manifestSha256'];env={**os.environ,'PATH':str(Path(node).parent)+':'+os.environ.get('PATH',''),'ANYRAID_ACCEPTANCE_BUNDLE':identity['path'],'ANYRAID_ACCEPTANCE_MANIFEST_SHA256':identity['manifestSha256'],'ANYRAID_ACCEPTANCE_DEPENDENCIES_SHA256':identity['dependenciesSha256']}
def run(name,args,cwd,extra=None):
 start=time.monotonic()
 with (ev/(name+'.log')).open('wb') as out:
  p=subprocess.Popen(args,cwd=cwd,stdout=out,stderr=subprocess.STDOUT,env={**env,**(extra or {})});print(json.dumps({'stage':name,'pid':p.pid,'log':str(ev/(name+'.log'))}),flush=True);code=p.wait()
 receipt={'command':args,'cwd':str(cwd),'pid':p.pid,'exitCode':code,'durationSeconds':time.monotonic()-start,'bundle':identity};(ev/(name+'.json')).write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt),flush=True);return code
assert not independent.exists() and not actual.exists()
assert run('linux-parallel-independent-emit',[node,'host/scripts/run-typescript.ts','-p','host/tsconfig.json','--noEmit','false','--noEmitOnError','true','--rewriteRelativeImportExtensions','true','--rootDir',str(root),'--outDir',str(independent)],root)==0
inventory=json.loads((app/'build-info.json').read_text());js=[p for p in inventory['files'] if p.endswith('.js')];assert all(sha(independent/p)==inventory['files'][p] for p in js)
(ev/'linux-parallel-independent-js-match.json').write_text(json.dumps({'matchedJavaScriptFiles':len(js),'includes':'All emitted product host/src runtime JS and root helper scripts inventoried by build-info; tests not counted as production','manifestSha256':identity['manifestSha256'],'differences':[],'files':{p:sha(independent/p) for p in js}},indent=2))
for destination in [independent]:
 shutil.copy2(app/'package.json',destination/'package.json');shutil.copytree(app/'node_modules',destination/'node_modules',symlinks=True);shutil.copytree(app/'host/assets',destination/'host/assets');shutil.copytree(app/'host/build',destination/'host/build');shutil.copy2(root/'host/test/helpers/pty.c',destination/'host/test/helpers/pty.c')
shutil.copytree(independent,actual,symlinks=True);assert (actual/'node_modules').resolve().is_relative_to(actual);shutil.rmtree(actual/'node_modules');(actual/'node_modules').symlink_to(app/'node_modules',target_is_directory=True);assert (actual/'host/src').resolve().is_relative_to(base);shutil.rmtree(actual/'host/src');(actual/'host/src').symlink_to(app/'host/src',target_is_directory=True)
for p in js:
 if p.startswith('scripts/'):
  target=actual/p;target.unlink();target.symlink_to(app/p)
(ev/'deny-ts.mjs').write_text("import {registerHooks} from 'node:module';registerHooks({resolve(specifier,context,next){if(/[.](?:ts|mts|cts)(?:[?#]|$)/u.test(specifier))throw Error('TypeScript loading forbidden: '+specifier);return next(specifier,context);}});\n")
selectors=['service-info','service-installation-process','fixed-node-install','legacy-node-install-bootstrap','system-bus-owner','sudo-owner','sudo-install-helper','machine-provider','native-product-process-lifetime','native-product-machine-control','native-install-bootstrap'];source=[f'host/test/{p}.test.ts' for p in selectors];compiled=[p[:-3]+'.js' for p in source];assert all((root/p).is_file() for p in source)
jsenv={'NODE_OPTIONS':'--no-experimental-strip-types --import '+str(ev/'deny-ts.mjs'),'NODE_PATH':''}
jobs=[('linux-parallel-independent-focused',[node,'--no-experimental-strip-types','--test','--test-reporter=tap',*compiled],independent,jsenv),('linux-parallel-product-focused',[node,'--no-experimental-strip-types','--test','--test-reporter=tap',*compiled],actual,jsenv),('linux-parallel-minimum-source',[minimum,'--test','--test-reporter=tap',*source],root,{'PATH':str(Path(minimum).parent)+':'+os.environ.get('PATH','')}),('linux-parallel-minimum-product',[minimum,'--no-experimental-strip-types','--test','--test-reporter=tap',*compiled],actual,{**jsenv,'PATH':str(Path(minimum).parent)+':'+os.environ.get('PATH','')})]
for name,args,cwd,extra in jobs:
 if run(name,args,cwd,extra):print(json.dumps({'failedStage':name,'continuingIndependentRemainingEvidence':True}),flush=True)
assert all(sha(root/r['path'])==r['sha256'] for r in freeze['files']);assert sha(app/'build-info.json')==identity['manifestSha256']

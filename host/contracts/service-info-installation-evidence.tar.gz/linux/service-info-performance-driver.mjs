import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile, mkdir, rm, cp, readdir, symlink, realpath } from 'node:fs/promises';
import { tmpdir, userInfo } from 'node:os';
import { join, dirname, resolve } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { stripTypeScriptTypes } from 'node:module';
import { setTimeout as delay } from 'node:timers/promises';
import { fixedInstallFixture, installHash } from "file:///home/dek02/.codex/worktrees/supervisor-group-compat/service-info-independent/host/test/helpers/fixed-install.js";
import { fixedInstallUnit } from "file:///home/dek02/.codex/worktrees/supervisor-group-compat/service-info-independent/scripts/product-install-helper.js";
import { buildProductHost } from "file:///home/dek02/.codex/worktrees/supervisor-group-compat/service-info-independent/host/scripts/build-product-host.js";
import { installProductDependencies } from "file:///home/dek02/.codex/worktrees/supervisor-group-compat/service-info-independent/host/test/helpers/product-install.js";
import { externalAcceptanceBundle, assertAcceptanceBundleUnchanged, assertSeparateAcceptanceWorkspace } from "file:///home/dek02/.codex/worktrees/supervisor-group-compat/service-info-independent/host/test/helpers/acceptance-bundle.js";
async function until(check, message = 'Installation process deadline') { const end = performance.now() + 20000; while (!await check()) {
    assert(performance.now() < end, message);
    await delay(5);
} }
async function fixture() {
    assert.equal(process.platform, 'linux', 'Actual /proc identity and native simulated transport require Linux');
    const retained = await externalAcceptanceBundle(), workspace = await mkdtemp(join(tmpdir(), 'service-info-process-')), app = retained?.path ?? join(workspace, 'app');
    let f;
    try {
        if (retained)
            await assertSeparateAcceptanceWorkspace(retained, workspace);
        else {
            await buildProductHost(app);
            await installProductDependencies(app);
        }
        const support = join(workspace, 'support'), helpers = join(support, 'host/test/helpers');
        await mkdir(helpers, { recursive: true });
        await writeFile(join(support, 'package.json'), '{"type":"module"}');
        await symlink(join(app, 'host/src'), join(support, 'host/src'), 'dir');
        await symlink(join(app, 'scripts'), join(support, 'scripts'), 'dir');
        await symlink(join(app, 'node_modules'), join(support, 'node_modules'), 'dir');
        // Only test helper erasure; all production imports resolve to the pinned actual product.
        const sourceHelpers = fileURLToPath("file:///home/dek02/.codex/worktrees/supervisor-group-compat/service-info-independent/host/test/helpers/");
        for (const entry of await readdir(sourceHelpers)) {
            if (entry.endsWith('.ts')) {
                const source = await readFile(join(sourceHelpers, entry), 'utf8'), js = stripTypeScriptTypes(source, { mode: 'strip' }).replace(/(['"])(\.[^'"\n]+)\.ts\1/gu, '$1$2.js$1');
                await writeFile(join(helpers, entry.slice(0, -3) + '.js'), js);
            }
            else if (entry.endsWith('.js') || entry === 'pty.c')
                await cp(join(sourceHelpers, entry), join(helpers, entry));
        }
        f = await fixedInstallFixture();
        f.manifest.node = await realpath(process.execPath);
        f.manifest.user = userInfo().username;
        f.manifest.bundle = await realpath(app);
        f.manifest.bundleManifestSha256 = installHash(await readFile(join(app, 'build-info.json')));
        f.manifest.candidateSha256 = installHash(fixedInstallUnit(f.manifest));
        f.options.candidateSha256 = f.manifest.candidateSha256;
        const boundProfile = `import {installationProcessProfile} from ${JSON.stringify(pathToFileURL(join(helpers, 'service-installation-process.js')).href)};\nexport const createProductHostProfile=await installationProcessProfile(${JSON.stringify({ root: f.root, manifestPath: f.manifestPath, unitPath: f.unitPath, options: f.options })});\n`;
        await writeFile(f.profile, boundProfile);
        f.manifest.profileSha256 = installHash(boundProfile);
        await writeFile(f.manifestPath, JSON.stringify(f.manifest));
        await writeFile(f.configFile, f.original + '[machine]\nprovider:systemd_cli\n');
        await writeFile(join(f.root, 'service-state.json'), '{"phase":"source"}');
        const running = new Set();
        async function start() {
            const child = spawn(f.manifest.node, ['--no-experimental-strip-types', join(app, 'scripts/product-host.js'), '--profile', f.profile], { env: { ...process.env, NODE_PATH: '', NODE_DISABLE_COMPILE_CACHE: '1' }, stdio: ['ignore', 'pipe', 'pipe', 'ipc'], detached: true }), messages = [];
            let stdout = '', stderr = '', code, exitSignal;
            const done = Promise.withResolvers();
            child.on('message', value => messages.push(value));
            child.stdout.on('data', b => { stdout += b; assert(stdout.length < 2 * 1024 ** 2); });
            child.stderr.on('data', b => { stderr += b; assert(stderr.length < 2 * 1024 ** 2); });
            child.once('error', done.reject);
            child.once('close', (value, signal) => { code = value; exitSignal = signal; done.resolve(); });
            const events = () => stdout.split('\n').filter(Boolean).map(line => { try {
                return JSON.parse(line);
            }
            catch {
                return {};
            } }), check = () => { assert(code === undefined, `Child exited ${code}/${exitSignal}: ${stderr}\n${stdout}`); };
            let stopped;
            const result = { child, messages, get stdout() { return stdout; }, get stderr() { return stderr; }, get code() { return code; }, async listening() { await until(() => { check(); return events().some(row => row.event === 'listening'); }); const address = events().find(row => row.event === 'listening').address; return 'http://127.0.0.1:' + address.port + '/printer'; }, async ready() { await until(() => { check(); return events().some(row => row.event === 'ready'); }); }, async request(path, body) { const base = await this.listening(); await until(() => messages.some(row => row.event === 'bootstrapped')); const key = messages.find(row => row.event === 'bootstrapped').key; return fetch(base + path, { method: body === undefined ? 'GET' : 'POST', headers: { 'x-api-key': key, 'content-type': 'application/json' }, ...body === undefined ? {} : { body: JSON.stringify(body) } }); }, async proof(event = 'same-process-proof') { child.send({ event }); await until(() => { check(); return messages.some(row => row.event === event); }); return messages.find(row => row.event === event); }, stop() { return stopped ??= (async () => { if (code === undefined)
                    child.kill('SIGTERM'); try {
                    await Promise.race([done.promise, delay(15000, undefined, { ref: false }).then(() => { throw Error('Child cleanup deadline'); })]);
                }
                catch (error) {
                    if (child.pid)
                        try {
                            process.kill(-child.pid, 'SIGKILL');
                        }
                        catch { }
                    await done.promise;
                    throw error;
                }
                finally {
                    running.delete(result);
                } })(); } };
            running.add(result);
            return result;
        }
        return { f, app, start, async events() { try {
                return (await readFile(join(f.root, 'events.jsonl'), 'utf8')).trim().split('\n').filter(Boolean).map(line => JSON.parse(line));
            }
            catch (error) {
                if (error.code === 'ENOENT')
                    return [];
                throw error;
            } }, async close() { const results = await Promise.allSettled([...running].map(child => child.stop())); try {
                if (retained)
                    await assertAcceptanceBundleUnchanged(retained);
            }
            finally {
                await f.close();
                await rm(workspace, { recursive: true, force: true });
            } const failed = results.filter(row => row.status === 'rejected'); if (failed.length)
                throw new AggregateError(failed.map(row => row.reason), 'Installation child cleanup failed'); } };
    }
    catch (error) {
        await f?.close();
        await rm(workspace, { recursive: true, force: true });
        throw error;
    }
}

export {fixture};

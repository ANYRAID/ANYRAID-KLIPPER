import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {join} from 'node:path';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
const base='/home/dek02/.codex/worktrees/supervisor-group-compat',ev=base+'/evidence/service-info',independent=base+'/service-info-independent',execute=promisify(execFile);
const registration=JSON.parse(await readFile(ev+'/service-info-performance-registration.json','utf8')),after=JSON.parse(await readFile(ev+'/linux-product-process-identity-fix1.json','utf8'));
assert.equal(registration.threshold,1.5);assert.equal(registration.cold.freshChildrenPerVariant,28);assert.equal(registration.reacquire.observationsPerVariant,28);assert.match(process.version,/^v26\.9\./);
const before=registration.baselineProduct,variants={before,after};
// Reuse exactly the frozen functional fixture, only relocate its parent-test imports.
let code=(await readFile(independent+'/host/test/service-installation-process.test.js','utf8')).split("test('default CLI factory")[0];
code=code.replace(/from (['"])(\.[^'"\n]+)\1/gu,(_all,quote,specifier)=>'from '+JSON.stringify(new URL(specifier,pathToFileURL(independent+'/host/test/service-installation-process.test.js')).href));
code=code.replace("new URL('./helpers/', import.meta.url)",JSON.stringify(pathToFileURL(independent+'/host/test/helpers/').href)).replace("new URL('./helpers/',import.meta.url)",JSON.stringify(pathToFileURL(independent+'/host/test/helpers/').href));
code+='\nexport {fixture};\n';const driver=ev+'/service-info-performance-driver.mjs';await writeFile(driver,code);const {fixture}=await import(pathToFileURL(driver).href);
const rows=[],owners={},preparation=[],absoluteCli=[],started=new Date().toISOString();let failure;
const receipt=()=>({schema:1,started,node:process.version,registration,variants,rows,preparation,absoluteCli,failure:failure?String(failure.stack??failure):null,scope:'Actual trusted default CLI installation-enabled factory, real listening/adapter-ready and authorized HTTP restart; fake fixed executable PATH and simulated MCU, no real systemd/device or print-performance claim'});
async function save(){await writeFile(ev+'/linux-factory-performance.json',JSON.stringify(receipt(),null,2)+'\n');}
async function until(check){const end=performance.now()+20000;while(!await check()){assert(performance.now()<end,'Performance fixture deadline');await new Promise(r=>setTimeout(r,5));}}
function use(bundle){process.env.ANYRAID_ACCEPTANCE_BUNDLE=bundle.path;process.env.ANYRAID_ACCEPTANCE_MANIFEST_SHA256=bundle.manifestSha256;process.env.ANYRAID_ACCEPTANCE_DEPENDENCIES_SHA256=bundle.dependenciesSha256;}
try{
 for(const name of ['before','after']){
  use(variants[name]);const owner=await fixture();owners[name]=owner;const first=await owner.start();await first.listening();const start=performance.now(),response=await first.request('/machine/sudo/password',{password:'fixture-password'});assert.equal(response.status,200,await response.clone().text());await until(async()=> (await owner.events()).some(row=>row.event==='helper-command'&&row.args.includes('restart')));const installMs=performance.now()-start;await first.stop();assert.equal(first.code,0,first.stderr);const journal=JSON.parse(await readFile(owner.f.options.recoveryPath,'utf8'));assert.equal(journal.phase,'version-confirmed');delete journal.transition;await writeFile(owner.f.options.recoveryPath,JSON.stringify(journal));preparation.push({variant:name,installHttpMs:installMs,journalPhase:journal.phase,transitionPresent:false,outsideTimedSampling:true});
  const cliStart=performance.now();await execute(join(owner.f.root,'fake-bin/systemctl'),['--no-pager','--no-ask-password','--full','status',String(process.pid)],{env:{...process.env,PATH:join(owner.f.root,'fake-bin')},timeout:2000,maxBuffer:65536});absoluteCli.push({variant:name,command:'fixed fake systemctl status',elapsedMs:performance.now()-cliStart,scope:'Absolute cold fake CLI child close only; not service-info authorization or printing performance'});await save();
 }
 for(let pair=0;pair<28;pair++)for(const variant of pair%2?['after','before']:['before','after']){
  use(variants[variant]);const owner=owners[variant],helperBefore=(await owner.events()).filter(row=>row.event==='helper-command').length,start=performance.now(),child=await owner.start();try{
   await child.listening();await child.ready();const coldMs=performance.now()-start;assert.equal(child.messages.filter(row=>row.event==='adapter').length,1);const reacquireStart=performance.now(),response=await child.request('/printer/restart',{});assert.equal(response.status,200,await response.clone().text());await until(()=>child.messages.filter(row=>row.event==='adapter').length===2);const reacquireMs=performance.now()-reacquireStart;assert.equal((await owner.events()).filter(row=>row.event==='helper-command').length,helperBefore,'Timed ready/reacquire must not perform an install effect');rows.push({pair,variant,pid:child.child.pid,coldMs,reacquireMs});await save();console.log(JSON.stringify(rows.at(-1)));
  }finally{await child.stop();assert.equal(child.code,0,child.stderr);}
 }
 const median=values=>{const sorted=[...values].sort((a,b)=>a-b);return (sorted[(sorted.length-1)>>1]+sorted[sorted.length>>1])/2;};
 const summaries={};for(const key of ['coldMs','reacquireMs']){const a=rows.filter(r=>r.variant==='before').map(r=>r[key]),b=rows.filter(r=>r.variant==='after').map(r=>r[key]);assert.equal(a.length,28);assert.equal(b.length,28);summaries[key]={beforeMedian:median(a),afterMedian:median(b),ratio:median(b)/median(a),threshold:1.5};assert(summaries[key].ratio<=1.5,JSON.stringify(summaries[key]));}await writeFile(ev+'/linux-factory-performance-summary.json',JSON.stringify({summaries,rowsPerVariant:28,registrationSha256:'a8159cb800ff9605896f9200b6b8d72cd969b065156ec0f9ac87b283e6573d44'},null,2)+'\n');console.log(JSON.stringify({summaries}));
}catch(error){failure=error;await save();throw error;}
finally{const cleanup=await Promise.allSettled(Object.values(owners).map(owner=>owner.close()));const failed=cleanup.filter(row=>row.status==='rejected');if(failed.length){failure??=new AggregateError(failed.map(row=>row.reason),'Performance fixture cleanup failed');await save();throw failure;}await save();}

import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,chmod} from 'node:fs/promises';
import {join} from 'node:path';
import {userInfo} from 'node:os';
import {pathToFileURL} from 'node:url';
const tree='/home/dek02/.codex/worktrees/supervisor-group-compat/ANYRAID-KLIPPER';
const load=path=>import(pathToFileURL(join(tree,path)).href);
const {fixedInstallFixture,installHash}=await load('host/test/helpers/fixed-install.ts');
const {fixedInstallUnit}=await load('scripts/product-install-helper.ts');
const {ProviderServiceInfo}=await load('host/src/moonraker/service-info.ts');
const {FixedNodeInstallValidator}=await load('host/src/moonraker/fixed-node-install.ts');
const {DatabaseStore}=await load('host/src/moonraker/database.ts');
const {NativeConfigFiles}=await load('host/src/moonraker/native-config-files.ts');
const {ConfigurationReader}=await load('host/src/moonraker/config-reader.ts');
const {loadConfiguration}=await load('host/src/moonraker/config-source.ts');
const {ProcessSudoOwner}=await load('host/src/moonraker/sudo-owner.ts');
const out=process.argv[2];assert(out);const f=await fixedInstallFixture(),oldPath=process.env.PATH,rows=[];
const hypothesis='A fixed anyraid.service fake show response conflicts with a real service-named cgroup; scope-only hosts do not expose the mismatch.';
const decision='If only modeled cgroup changes pending to generic blocked, propose test fixture unit alignment and child diagnostics; do not weaken production owner checks. This does not capture GitHub actual cgroup.';
try{
 f.manifest.user=userInfo().username;f.manifest.candidateSha256=installHash(fixedInstallUnit(f.manifest));f.options.candidateSha256=f.manifest.candidateSha256;await writeFile(f.manifestPath,JSON.stringify(f.manifest));
 const bin=join(f.root,'bin'),cliLog=join(f.root,'cli.jsonl');await mkdir(bin);
 const cli=`#!${process.execPath}\nimport {readFileSync,appendFileSync} from 'node:fs';const m=JSON.parse(readFileSync(${JSON.stringify(f.manifestPath)},'utf8')),args=process.argv.slice(2);appendFileSync(${JSON.stringify(cliLog)},JSON.stringify({pid:process.ppid,child:process.pid,args})+'\\n');if(args.includes('status'))process.stdout.write('* '+m.unit+' - Fixture service\\n');else if(args.includes('show')){const p={Id:m.unit,MainPID:String(process.ppid),LoadState:'loaded',User:m.user,Group:'',Requires:'',After:'network.target',SupplementaryGroups:'',EnvironmentFiles:m.dataPath+'/systemd/moonraker.env (ignore_errors=no)',ExecStart:'{ path=/usr/bin/python ; argv[]=/usr/bin/python -m moonraker ; ignore_errors=no ; start_time=[] ; stop_time=[] ; pid=0 ; code=(null) ; status=0 }',WorkingDirectory:'/',FragmentPath:'/etc/systemd/system/'+m.unit,Description:'Fixture'};process.stdout.write(Object.entries(p).map(([k,v])=>k+'='+v).join('\\n')+'\\n');}else throw Error('Unexpected read-only fake CLI action');\n`;
 await writeFile(join(bin,'systemctl'),cli);await chmod(join(bin,'systemctl'),0o700);process.env.PATH=bin;
 for(const [label,cgroup] of [['scope','0::/user.slice/session.scope\n'],['service','0::/system.slice/actions.runner.synthetic.service\n']]){
  const operations=[],info=new ProviderServiceInfo('systemd_cli',{}, {cgroup:async()=>cgroup});
  const backend={async deployment(signal){signal.throwIfAborted();const b=await readFile(f.manifestPath);return {...JSON.parse(b.toString()),manifestSha256:installHash(b)};},async execute(operation){operations.push(operation);if(operation==='status'){const e=new Error('No installed proof in source fixture');e.code='ENOENT';throw e;}if(operation==='probe')return {schema:1,phase:'installed',candidateSha256:f.manifest.candidateSha256,unitSha256:f.manifest.candidateSha256,backup:null,envBackup:null};throw Error('No installation effects permitted in diagnostic');},async close(){}};
  const db=await DatabaseStore.open({path:f.databasePath}),files=await NativeConfigFiles.open({root:f.configRoot,writable:['moonraker.conf']}),sudo=new ProcessSudoOwner(backend,()=>{},async()=>{}),reader=new ConfigurationReader(await loadConfiguration(f.configFile));
  const validator=new FixedNodeInstallValidator({...f.options,serviceInfo:info},reader,files,db,sudo);
  try{
   await validator.initialize(new AbortController().signal);
   const row={label,cgroup,pid:process.pid,installationStatus:validator.status,sudoSnapshot:sudo.snapshot,cliCalls:(await readFile(cliLog,'utf8')).trim().split('\n').map(JSON.parse),operations};
   if(label==='service')row.passwordResult=await sudo.setPassword('fixture-password',{transport:'http',signal:new AbortController().signal,authorize(){return {username:'operator'};},afterResponse(){}});
   rows.push(row);
  }finally{await validator.close();await sudo.close();await files.close();await db.close();await info.close();}
 }
 assert.equal(rows[0].installationStatus.state,'pending');assert.equal(rows[0].sudoSnapshot.sudo_requested,true);
 assert.equal(rows[1].installationStatus.state,'blocked');assert.equal(rows[1].sudoSnapshot.sudo_requested,false);
 assert.equal(rows[1].installationStatus.message,'Fixed Node layout or installation outcome requires administrator reconciliation');assert.equal(rows[1].passwordResult.is_restarting,false);
 const result={hypothesis,decision,node:process.version,actualCgroup:await readFile('/proc/self/cgroup','utf8'),modeledInputs:true,fixtureUnit:f.manifest.unit,rows,productionChecksUnchanged:true,noSystemdOrDeviceActions:true};
 await writeFile(out,JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result,null,2));
}finally{if(oldPath===undefined)delete process.env.PATH;else process.env.PATH=oldPath;await f.close();}

# CI 测试夹具修正根审计

当前任务分支为 devac/moonraker-template-owner，基线为 8e28228562cfa5c7e39438469ec6631822d04fad。修正尚未提交。

## 已复核

- 四个测试及 helper 文件差异：夹具服务名随实际 cgroup 选择，服务名先校验再创建目录；manifest、unit 路径与假后端证明使用同一名称。
- 产品 service-info.ts 身份校验未改动。当前 PID、startTicks、unit、LoadState 与 cgroup 稳定性校验仍保留。
- 等待期限仍为 20 秒，测试期限未扩大。新增诊断只在失败时计算或启动时记录选定字段，不输出 IPC API key；诊断读失败不改变原启动结果。
- 原始 TAP：Node 26.11.1 与 26.9.0 三文件各 30 tests、30 pass，fail/cancelled/skipped/todo 均为 0。
- Linux 全仓类型检查 receipt：exit 0、3235ms；三批均无超时和残留进程。
- 最终 receipt：cd91f2e3242a2cd392e8489f7026fd3cd730470ec8cf03d9113332546cfc67d3 产品与 0b53079c853e4894141cf231e68b278c04de0db39fc26ea8e6326742f2e01fd4 依赖前后不变。
- GitHub 实时查询：8e2 的 Build test 38737418063、Node motion diagnostics 38737418059 成功；Node host 38737418072 失败。

## 证明边界

配对诊断证明固定 anyraid.service 响应与不同 service cgroup 会造成身份不匹配；原 CI 未记录实际 cgroup，因此不能认定其已证实为 CI 根因。Linux 回归来自 scope 环境，需候选新头 CI 核验真实服务环境。当前未改生产代码，没有新的性能结果；原服务重获 2.62602 倍失败与历史失败均保持未关闭。

本批后续应封存原始失败、建模诊断、候选输入哈希和两版本回归证据，再按正常 PR 流程推进。客户端默认只验 Mainsail，不重复 Fluidd。此审计不证明完整 Moonraker、Python 全面退役、运动精度或实机交付。

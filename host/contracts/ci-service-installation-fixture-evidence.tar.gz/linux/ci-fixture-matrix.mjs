import {spawn} from 'node:child_process';
import {createWriteStream} from 'node:fs';
import {readFile,writeFile} from 'node:fs/promises';
import {setTimeout as delay} from 'node:timers/promises';
import {createHash} from 'node:crypto';
import {inspectAcceptanceBundle} from 'file:///home/dek02/.codex/worktrees/supervisor-group-compat/ANYRAID-KLIPPER/host/test/helpers/acceptance-bundle.ts';
const base='/home/dek02/.codex/worktrees/supervisor-group-compat',tree=base+'/ANYRAID-KLIPPER',out=base+'/evidence/client-external-fault',app=base+'/client-reset-product';
const node=base+'/node26.9/node-v26.9.0-linux-x64/bin/node',current='/home/dek02/.cache/codex/tmp/legacy-install-oct14/node26.11.1/node-v26.11.1-linux-x64/bin/node';
const expected={manifestSha256:'cd91f2e3242a2cd392e8489f7026fd3cd730470ec8cf03d9113332546cfc67d3',dependenciesSha256:'0b53079c853e4894141cf231e68b278c04de0db39fc26ea8e6326742f2e01fd4'},hash=b=>createHash('sha256').update(b).digest('hex');
const freeze=JSON.parse(await readFile(out+'/ci-fixture-inputs.json','utf8'));
async function verify(){for(const f of freeze.files)if(hash(await readFile(tree+'/'+f.path))!==f.sha256)throw Error('Frozen test changed: '+f.path);const product=await inspectAcceptanceBundle(app);for(const k of Object.keys(expected))if(product[k]!==expected[k])throw Error('Product identity changed');return product;}
const before=await verify();await writeFile(out+'/ci-fixture-matrix-marker.json',JSON.stringify({started:Date.now(),before,inputs:freeze.files},null,2)+'\n',{flag:'wx'});
const identity=async pid=>{try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),f=raw.slice(raw.lastIndexOf(')')+2).split(' ');return {pid:Number(pid),startTicks:f[19],state:f[0]};}catch{return null;}};
async function run(label,command,limit){
 const started=Date.now(),hardDeadline=started+limit*1000,stream=createWriteStream(out+'/'+label+'.log',{flags:'wx'}),child=spawn(command[0],command.slice(1),{cwd:tree,env:{...process.env,NODE_PATH:'',NODE_DISABLE_COMPILE_CACHE:'1',ANYRAID_ACCEPTANCE_BUNDLE:app,ANYRAID_ACCEPTANCE_MANIFEST_SHA256:expected.manifestSha256,ANYRAID_ACCEPTANCE_DEPENDENCIES_SHA256:expected.dependenciesSha256},stdio:['ignore','pipe','pipe'],detached:true});child.stdout.pipe(stream,{end:false});child.stderr.pipe(stream,{end:false});
 const known=new Map(),root=await identity(child.pid);if(root)known.set(root.pid,root);let ended=false,result,stage=0,deadline=hardDeadline,unexpectedResidual=false;
 child.once('error',error=>{result={errorCode:error.code??'spawn-error'};});child.once('close',(code,signal)=>{ended=true;result={...result,code,signal};});
 async function census(){for(const old of [...known.values()]){const live=await identity(old.pid);if(live?.startTicks!==old.startTicks||live.state==='Z')continue;let kids=[];try{kids=(await readFile('/proc/'+old.pid+'/task/'+old.pid+'/children','utf8')).trim().split(/\s+/).filter(Boolean);}catch{}for(const pid of kids){if(known.has(Number(pid)))continue;const item=await identity(pid);if(item)known.set(item.pid,item);}}const active=[];for(const old of known.values()){const live=await identity(old.pid);if(live?.startTicks===old.startTicks&&live.state!=='Z')active.push(live);}return active;}
 await writeFile(out+'/'+label+'-running.json',JSON.stringify({pid:child.pid,command,started,deadline:hardDeadline,limitSeconds:limit},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({stage:label,pid:child.pid,deadline:hardDeadline,log:out+'/'+label+'.log'}));
 for(;;){const active=await census();if(ended&&!active.length)break;const now=Date.now();if(ended&&active.length&&!unexpectedResidual){unexpectedResidual=true;deadline=Math.min(deadline,now+5000);}const wanted=now>=deadline-1000?2:now>=deadline-5000?1:0;if(wanted>stage){stage=wanted;for(const old of active.toReversed()){const live=await identity(old.pid);if(live?.startTicks===old.startTicks)try{process.kill(old.pid,stage===2?'SIGKILL':'SIGTERM');}catch{}}}if(now>=deadline)break;await delay(20);}
 await new Promise(resolve=>stream.end(resolve));const remaining=await census(),receipt={pid:child.pid,command,started,deadline:hardDeadline,ended:Date.now(),elapsedMs:Date.now()-started,...result,timeout:stage>0&&!unexpectedResidual,unexpectedResidual,remaining,knownProcesses:[...known.values()]};await writeFile(out+'/'+label+'.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));if(result?.code!==0||stage||remaining.length)throw Error('Failed stage '+label);
}
await run('ci-fixture-linux-typecheck',[current,'host/scripts/run-typescript.ts','-p','host/tsconfig.json'],120);
const tests=['fixed-node-install','service-info','service-installation-process'].map(n=>'host/test/'+n+'.test.ts');
await run('ci-fixture-linux-26.11-three',[current,'--test','--test-concurrency=1','--test-reporter=tap',...tests],600);
await run('ci-fixture-linux-26.9-three',[node,'--test','--test-concurrency=1','--test-reporter=tap',...tests],600);
const after=await verify();await writeFile(out+'/ci-fixture-matrix-final.json',JSON.stringify({finished:Date.now(),before,after,inputsUnchanged:true,productionRebuilt:false,nativeRebuilt:false,dependenciesReinstalled:false},null,2)+'\n',{flag:'wx'});

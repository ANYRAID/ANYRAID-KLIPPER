// Diagnostic only. No argv/env/payload/stderr capture or event/kill semantic changes.
import {ChildProcess} from 'node:child_process';
import {openSync,writeSync,readFileSync,closeSync} from 'node:fs';
import {basename} from 'node:path';
import {threadId} from 'node:worker_threads';
const marker=Symbol.for('anyraid.exit-observer.once');
if(!globalThis[marker]){
globalThis[marker]={initialized:false};
const directory='/home/dek02/.codex/worktrees/supervisor-group-compat/evidence/exit-resource-once';
function proc(pid){try{const raw=readFileSync('/proc/'+pid+'/stat','utf8'),v=raw.slice(raw.lastIndexOf(')')+2).split(' ');return{pid:Number(pid),ppid:Number(v[1]),startTicks:v[19]};}catch{return{pid:Number(pid),identityUnavailable:true};}}
const self=proc(process.pid);let fd;
function facilityFailure(){try{process.stderr.write('{"exitObserverFacilityFailure":true}\n');}catch{}}
try{fd=openSync(directory+'/events-'+process.pid+'-'+(self.startTicks??'unknown')+'-t'+threadId+'.jsonl','wx',0o600);}catch{facilityFailure();}
if(fd!==undefined){
let sequence=0,writeFailed=false;
const quotas={target:{lines:0,bytes:0,maxLines:1024,maxBytes:256*1024,capped:false},other:{lines:0,bytes:0,maxLines:256,maxBytes:64*1024,capped:false}};
function log(event,data={}){const bucket=String(data.role??'').match(/^(?:product-host-(?:source|compiled|test)|thumbnail-(?:source|compiled|process-test)|source-brake-test)$/)?'target':'other',quota=quotas[bucket];if(quota.capped||writeFailed)return;try{if(quota.lines>=quota.maxLines-1||quota.bytes>=quota.maxBytes-1024){const row=JSON.stringify({sequence:++sequence,at:Date.now(),monoNs:process.hrtime.bigint().toString(),event:'observer-cap',bucket})+'\n';writeSync(fd,row);quota.capped=true;return;}const row=JSON.stringify({sequence:++sequence,at:Date.now(),monoNs:process.hrtime.bigint().toString(),event,bucket,...data})+'\n';writeSync(fd,row);quota.lines++;quota.bytes+=Buffer.byteLength(row);}catch{writeFailed=true;facilityFailure();}}
const errorMeta=e=>({name:typeof e?.name==='string'?e.name.slice(0,64):'unknown',...typeof e?.code==='string'&&/^[A-Z0-9_]{1,64}$/.test(e.code)?{code:e.code}:{}});
const entries=[['/scripts/product-host.ts','product-host-source'],['/scripts/product-host.js','product-host-compiled'],['/thumbnail-process-child.ts','thumbnail-source'],['/thumbnail-process-child.js','thumbnail-compiled'],['/test/source-brake.test.ts','source-brake-test'],['/test/product-host.test.ts','product-host-test'],['/test/thumbnail-process.test.ts','thumbnail-process-test']];
function classify(options){const args=Array.isArray(options?.args)?options.args:[];for(const [suffix,role]of entries)if(args.some(v=>typeof v==='string'&&v.endsWith(suffix)))return role;const name=typeof options?.file==='string'?basename(options.file):'';return name==='node'||name==='node.exe'?'other-node':['cc','gcc','g++','clang','rustc','cargo'].includes(name)?'compiler':'other-child';}
const children=new WeakMap(),originalSpawn=ChildProcess.prototype.spawn,originalEmit=ChildProcess.prototype.emit,originalKill=ChildProcess.prototype.kill;
const selfRole=classify({file:process.execPath,args:[process.argv[1]]});
log('observer-start',{...self,threadId,role:selfRole,node:process.version,execPath:process.execPath,binaryIdentity:'Hash once in external preflight; not reread per worker',coverage:'Direct ChildProcess events in this imported process only'});
ChildProcess.prototype.spawn=function(options){const meta={role:classify(options)};children.set(this,meta);log('child-create',meta);try{return originalSpawn.call(this,options);}catch(error){log('child-spawn-throw',{...meta,...errorMeta(error)});throw error;}};
ChildProcess.prototype.emit=function(event,...args){if(['spawn','exit','close','disconnect','error'].includes(event)){const meta=children.get(this)??{role:'unclassified-direct-child'};if(event==='spawn'){Object.assign(meta,proc(this.pid));children.set(this,meta);}log('child-'+event,{...meta,...typeof this.pid==='number'?{pid:this.pid}:{},...event==='exit'||event==='close'?{code:args[0]??null,signal:args[1]??null}:{},...event==='error'?{error:errorMeta(args[0])}:{}});}return originalEmit.call(this,event,...args);};
ChildProcess.prototype.kill=function(signal){const meta=children.get(this)??{role:'unclassified-direct-child'},requested=signal??'SIGTERM',safeSignal=typeof requested==='number'?requested:typeof requested==='string'&&/^SIG[A-Z0-9]{1,16}$/.test(requested)?requested:'unrecognized';log('child-kill-call',{...meta,...typeof this.pid==='number'?{pid:this.pid}:{},signal:safeSignal});try{const result=originalKill.call(this,signal);log('child-kill-return',{...meta,...typeof this.pid==='number'?{pid:this.pid}:{},signal:safeSignal,result});return result;}catch(error){log('child-kill-throw',{...meta,...typeof this.pid==='number'?{pid:this.pid}:{},signal:safeSignal,error:errorMeta(error)});throw error;}};
globalThis[marker].initialized=true;
process.on('exit',code=>{log('observer-process-exit',{role:selfRole,code,quotas,writeFailed});try{closeSync(fd);}catch{}});
}
}

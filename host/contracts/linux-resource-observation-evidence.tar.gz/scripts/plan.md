# 同等登记负载的资源诊断：仅准备，未运行

新review `/home/dek02/.codex/worktrees/supervisor-group-compat/evidence/exit-resource-review`；唯一out为同父目录`exit-resource-once`，存在即拒绝。复用上次fix1 owner/observer/guard；原once/fix1/A和已提交两包均不覆盖。仅一个外owner的一次pretest＋普通默认并发全测，不追加样本，不改断言、取消、生命周期或失败退出行为。

输入：本地55a94cfe当前1822登记文件的字节／SHA均与上次expected-inputs原字节一致，顶层test入口829且集合精确匹配；原expected-inputs SHA保持2ab8cace。当前head单列，远端实际head也记录；若远端登记输入／额外tracked集合不同则停供审，不自动同步。仅前次证据文档改变不冒称生产源码改变。原9直接入口与历史相同比较仍不是原5354完全同环境复现。

工具：固定Node26.11.1 SHA5a7b8a3c；已有Rust1.89／GCC12.3／ar／ld的原SHA及启动环境不变。补只读核Go版TS7.0.2 binary（24101026bytes／4f2de678），不重装／升级。CARGO／RUSTC／HOME和PATH仅沿用已审子进程env，无jobs／taskset／test-concurrency／compiler flags改动。复用已有缓存，不清cache；不称完全复制上轮缓存、调度或内存状态。完整test命令仍只加同一exit observer（仅out换独立路径）。源pretest原生输出前／后另记，1735固定包726文件／9addon及0b530依赖前后仍核，不能混为新源构建产物。

新增资源模块仅运行于外owner，不注入被测进程。实际owner/pretest/test PID／startTicks、limits／cgroup在读取前后核身份，短暂消失或复用明确不可用，不暂停进程凑采样，也不采每个compiler孙进程完整limits。阶段run-before(preflight)→before-stage→stage-start→stage-exit→run-after均保存wall＋mono；周期样本有实际阶段字段。nodeTestFailure仅保存report-received wall／mono，可能footer才送到，绝不当实际crash时刻；exit／close／owner kill亦有mono。

初始样本及每1秒名义周期、实际阶段退出后，串行读取实际cgroup及必要祖先直到root：memory.events／events.local／current／peak／high／max、swap current／peak／high／max／events、memory.pressure。累计peak和计数保留前值，不清零；同一祖先去重。系统固定读取MemTotal／MemAvailable／SwapTotal／SwapFree／CommitLimit／Committed_AS和/proc/pressure/memory；启动只读overcommit_memory／ratio／kbytes。ENOENT／ENODEV标not-supported（root部分memory文件确可不存在），其他读取／写入错误为明确采样设施失败并停止负载。

所有样本同一队列无重叠；慢采样时跳过已错过周期并计skippedCadences，不积压补采、不延迟被测进程。最多1024行／32MiB、每个度量16KiB／祖先登记32，超限明确设施失败并收口。样本给出开始和完成mono，不能把多文件读视为原子快照。标准两流仍各16MiB，observer target／other配额不变；没有argv／环境值／IPC／任意业务日志，资源字段均固定白名单，无sudo／sysctl／工具安装。

900秒整体／780秒停新阶段／870秒强制清理；原独立Linux guard SHA7f94e269原样复用，按登记PID/startTicks清理，只此任务树。正常或首次失败仍join关闭，记录原始两流、资源原始样本、实际owner/guard身份及终态。资源采样失败不能当产品失败或未复现成功。准备中曾因多余补丁anchor断言失败，修正后所有JS语法检查通过；没有启动测试或更改远端。

假设和可证伪边界：上轮1024字节分配失败、跨Rust/GCC/Go/Node异常提出资源条件假设，不预判OOM或硬件。root事后session906祖先high累计4372／峰值约15.5GB且max/oom0只能作选取祖先前值的依据，不能归本轮或旧场。本次若实际失败时祖先high/max/oom等新增、PSI增长、MemAvailable/SwapFree下降或Committed_AS接近CommitLimit，并能与真实exit而非延迟reporter接收关联，支持资源压力线索；共享祖先和同期其他活动仍妨碍唯一因果归属。

若相同失败仍出现而已采cgroup无事件增量、系统/commit仍有余量且压力低，则削弱已观测全局／cgroup压力解释，但不能排除采样间隙峰值、仅孙进程限制、工具链／runtime缺陷或硬件。若未再失败，只称这一轮有限未复现，不关闭历史11／当前16／G3，不再刷低载解析或全测次数。当前仅准备，等待根审具体SHA后才允许这一唯一场启动。

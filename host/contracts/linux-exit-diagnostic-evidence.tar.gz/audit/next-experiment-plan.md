# 下一步候选，仅供审查，未启动

当前一次诊断为当前70c64329源码、Node26.11.1、原默认测试并发；原5354集合及未记录的工具环境并未完全复现。首次once的cargo ENOENT属于环境准备失败，独立fix1的5341/5325/16属于真实失败，均保留。当前没有可据此修改产品逻辑的结论。

优先A：两个失败入口的最小解析检查。固定同一个Node26.11.1 SHA、原源码字节和空NODE_OPTIONS，不切换JIT、类型剥离、栈、内存或并发参数，不执行测试断言、构建或项目模块顶层代码。拟对published-copy.test.ts、ufp-archive.test.ts各做固定12个fresh-process `node --check <absolute-entry.ts>`，交替顺序，共24次；<=120秒外owner，90秒停止新动作、105秒强制清理，首次实际解析失败即保存并收口，不补样本。此处`--check`是明确的解析诊断模式，不冒充原完整test调用。启动前应核定该版本check对TS确走内置strip路径；若不相同则停止供审，不换模式求绿。

实际child每次在启动后记录PID/startTicks、/proc/PID/limits、/proc/PID/cgroup和该cgroup的memory.events/current/peak/max前后；采集竞态应写不可用，不能补造已退出进程。由外部owner读取，子进程不加载observer，不改其execArgv/env。保留exit/close/error、code/signal、原始有界stdout/stderr和二进制/输入SHA。无需更换预构建1735或运行pretest。

A能区分：同入口在无全量并发和无项目执行时仍失败，支持证明该入口的较小解析模式也可复现；首次失败收口本身不证明确定性或失败率；结果全部通过仅说明这24次入口解析未复现，不能排除加载到的传递依赖、Node loader路径差异、瞬态环境/并发压力。原栈未给出实际失败TS文件名，因此入口解析通过不能声称所有传递模块正常。若需扩到传递闭包，应另登记静态路径和SHA再审，不自动扩展。

备选B：项目无关的已安装二进制完整性/执行稳定性检查。当前PATH无memtester/stress-ng；不安装，不自制复杂压力器。可另审一个<=120秒owner，对已存在sha256sum和注册固定普通文件做6个独立进程、固定次数的digest比较，保存实际limits/cgroup前后与退出信号。它不依赖Node/Rust/TS或项目逻辑。任何错误digest或信号支持更广的执行/环境问题，不能直接证明硬件；全通过只约束低内存哈希工作负载，不能排除内存压力或编译器问题。它不等同内存稳定性通过，也不是memtester的替代。

建议先A。A直接对应本轮两个Node内置剥离错误，成本更小、解释更窄；B仅在A仍不能收窄时再决定。任何新场均须根审具体脚本/输入/清理边界后才启动。本文件没有授权新负载。

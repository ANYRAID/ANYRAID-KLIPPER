# 两项未知子进程退出与source-brake：一次当前候选诊断（未启动）

- 只读来源：supervisor-group-evidence.tar.gz的linux-full-npm-test.log:6113–6118／6201–6210及linux-full-npm-test-failures.json。host SIGTERM(delta=false)116.158ms在ready前退出，stderr空；thumbnail active-cancellation17.296ms首先disconnect503。两者原code/signal未保存；source-brake另有明确SIGSEGV，不能推给前两者。
- 当前9个直接入口相对51f583ae blob相同；完整测试集合不是同一版本。根已核历史至当前另有17个test/helper差异，runner/scripts/workflow未改；本次只能称当前候选完整负载诊断，不能冒称原5354完全复现。三文件顺序绿色不足保留原背景，不选此替代。
- 建议仅一次完整pretest及全量test/*.test.ts，普通多核／默认test并发，原Node26.11.1二进制SHA5a7b8a3c…，不taskset、不降并发、不改取消／SIGSTOP／SIGCONT／超时／清理断言。原npm test展开为npm run pretest，随后原node --test双reporter/glob命令只增加--import本诊断模块。该加载差异明确记录；不设置或覆盖NODE_OPTIONS，不改写／过滤process.execArgv，不改变owner显式execArgv。预检若原NODE_OPTIONS非空则停止供审，不静默覆盖。
- preload仅旁观ChildProcess.prototype.spawn／emit／kill：原方法参数、返回、throw及事件分派原样。每个进程独立wx文件，按本进程顺序号／hrtime与wallclock记录spawn/exit/close/disconnect/error、PID／PPID／startTicks；kill记录调用前后、信号及布尔返回，区分自然退出与owner后续补杀。禁止IPC内容、完整argv/env、任意stderr；error只name/code。二进制hash在启动前owner只读核一次，不每个test重读整个Node增添大量IO。
- 最关键判别：disconnect→owner kill(SIGKILL)→exit(SIGKILL)只证明后续清理，不把该signal当原始故障。自然exit在任何owner kill前已有code/signal则单列。host parent捕获code/signal不依赖被截断的ready.reject文案；thumbnail保持原stderr ignore与现有fail时序。
- 根node--test与继承该import的test worker可观察其直接ChildProcess。worker/owner自行指定execArgv时不注入／改写；未加载observer的产品/thumbnail child内部原生孙进程或线程不受此旁观覆盖。上层仍记录它的实际exit/close。日志需明确coverage，不声称观察全部native/compiler后代。
- 每进程／threadId独立文件：目标7类保留1024行／256KiB，其他事件另256行／64KiB，两配额互不耗尽、各自cap标记。重复同isolate加载用Symbol只包装一次；目录及写权限先预检，open/write失败仅固定设施失败标记、不改变原事件分派。记录自进程Node版本和execPath、/proc身份，关联启动前Node及原生二进制清单；不装全局uncaught handler、不吞原throw、不加自动重启。
- 外owner建议总900秒：原全量496.755秒可留余量；780秒不开始后继阶段，870秒精确拥有树TERM/KILL，900秒核终态。原测试自身15秒／5秒／20ms等限时不改；超时或失败保留单次结果，不追加样本。子进程失败仍等待close/join，清理只按PID/startTicks拥有树。pretest失败即不继续测试，不借旧native输出绕过。
- 184只读：当前6.18.36-amd64-desktop-rolling、Ryzen5 3500X、MemTotal16309096kB。原logmtime2026-10-15 05:19:28+08、摘要05:30:29，无原绝对start；以05:00–05:40为有界旁证窗口，不称精确发生时间。journal-k提示系统日志不可见并No entries，dmesg EPERM，EDAC无可读计数；MCE／EDAC／OOM／segfault内核原因未知，不提权或扩大扫描。
- owner.mjs预检1822个生产／test／scripts／native／C输入和包锁SHA及额外tracked文件集合，任何184差异先停供审、不自动同步。核Node26.11.1 exactSHA、NODE_OPTIONS为空；记录pretest旧／新source host/build/*.node身份（失败时亦记）。1735固定产品目录只读前后核manifest／native／包锁，不冒充新source构建为1735。
- Linux守卫复用已审版本，删去已死亡／PID复用的非root条目；活跃树4096容量溢出先TERM root与登记树、5秒后KILL，写capacity-failure-cleaned或residual-failure终态，不能裸throw失去守卫。root提前退出同样立即清理，780停止／870强制／900终态不变。标准pretest/test两流各限16MiB保存0600原始scratch日志，不打印或自动归档，后续仅经白名单脱敏审查；超限或observer设施标记立即停止并单列失败。observer本身仍不采任意stderr／argv／IPC。子错误仍join close。
- 基线51f583ae有823个顶层test文件，历史5354含其后11文件Supervisor overlay（含新增supervisor-group-control.test.ts），不能把823当作原5354完整清单；当前829个顶层test文件。基线→当前17个test/helper变化，另scripts/product-install-helper.ts变过，测试runner／host/scripts／workflow无变化；当前诊断不称历史完全同集合。
- 先审本计划／exit-observer.mjs／owner.mjs及watchdog.patch。尚未创建远端运行目录、未启动pretest或测试、未改产品／Git。一次诊断即使绿色仍只能报告未复现，不能关闭原11失败、G3或构建稳定性；若得到失败事件再选择一个可证明的主缺口实现。

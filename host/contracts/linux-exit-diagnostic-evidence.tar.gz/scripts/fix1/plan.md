# fix1：仅修正诊断子进程工具环境（未启动）

- 原exit-diagnostics-once及两完整流保留：pretest 6321ms内因cargo ENOENT停止，Rust编译未启动；不是ICE／SIGSEGV。原C阶段已重编，10个source native前后SHA相同。fixed1735逐726文件／9native／deps0b530前后相同。
- 新独立exit-diagnostics-fix1-review／exit-diagnostics-fix1-once，不覆盖旧目录。observer仅替换新out常量；guard／1822输入清单不变。仍900总限／780停新阶段／870强制；原Node26.11.1、默认CPU0–5／测试并发不变，只一次完整pretest＋全test glob。
- toolchains.json登记原日志指向的既有Rust1.89工具链实际cargo／rustc及GCC12.3、ar、ld路径／hash／版本前缀。子进程明确CARGO／RUSTC／CARGO_HOME／RUSTUP_HOME和Node/Rust bin PATH前缀；不改系统PATH，不安装升级，不写旧e068工具树。
- 使用当前隔离task cargo-home，保持CARGO_TARGET_DIR未设置（build-template默认当前隔离host/node_modules/.cache/template-target）；不换成CPU0产品构建target，不设置CARGO_BUILD_JOBS或taskset。若外部已有jobs／target覆盖则停供审，不静默清除。
- 原历史full wrapper未保存CARGO／RUSTC／home／PATH／jobs，无法验证其继承值；CPU0/jobs1只属于另一次product build。此场明确是当前候选＋原Node／已有工具的有界诊断，不声称旧5354同环境复现。
- 预检Node、空NODE_OPTIONS、1822源码及额外tracked集合、固定1735完整清单／依赖不变，并在任何pretest前逐工具X_OK／SHA／--version。任何不同保留新预检即停，不自动同步／重跑。
- 标准两流各16MiB只存scratch、无自动归档，observer不采argv/env/payload/stderr；目标独立配额、两流跨chunk设施marker、kill/exit顺序和原测试取消语义均不变。
- 已有cargo-home及所查repo／祖先.cargo/config(.toml)无jobs配置；rustup/settings仅1.89默认工具链／minimal。不能据当前配置倒推历史full环境。
- 先根审owner.patch／observer.patch／toolchains.json和最终SHA，再传新目录执行。当前未传输／未启动fix1，Git产品源码不变。

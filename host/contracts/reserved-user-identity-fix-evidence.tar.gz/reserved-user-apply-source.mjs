import {readFile,writeFile,stat} from 'node:fs/promises';import{join}from'node:path';import{createHash}from'node:crypto';import assert from'node:assert/strict';
const root='/home/dek02/.codex/worktrees/supervisor-group-compat/ANYRAID-KLIPPER',stage=process.argv[2];assert(stage?.startsWith('/home/dek02/.codex/worktrees/supervisor-group-compat/evidence/reserved-user-fix-'));
const hash=b=>createHash('sha256').update(b).digest('hex'),before={
'host/src/moonraker/api-key-authorization.ts':'582abf20ec9330dbd5f269fb583d0794873ddcd13b4c259031dc20406729176e',
'host/src/moonraker/legacy-authorization-startup.ts':'d4348b1deea40dd48a33f92493a9d4716c66783e61b247bc2408b51ad0d60788',
'host/test/legacy-authorization-startup.test.ts':'185a5cd998e070082c2b9e890e3863b4e3b6fd03a55d015ed131ce36bbf51a72',
'host/test/reserved-user-identity.test.ts':null};
const manifest=JSON.parse(await readFile(join(stage,'source/manifest.json'),'utf8'));assert.equal(manifest.files.length,4);const rows=[];
for(const row of manifest.files){assert(Object.hasOwn(before,row.path));const candidate=await readFile(join(stage,'source',row.path));assert.equal(hash(candidate),row.sha256);let original;try{assert((await stat(join(root,row.path))).isFile());original=await readFile(join(root,row.path));}catch(e){if(e.code!=='ENOENT')throw e;}assert.equal(original?hash(original):null,before[row.path]);rows.push({...row,beforeSha256:before[row.path]});}
for(const row of rows){const target=join(root,row.path);await writeFile(target,await readFile(join(stage,'source',row.path)),{flag:row.beforeSha256?'w':'wx'});assert.equal(hash(await readFile(target)),row.sha256);}
await writeFile(join(stage,'transfer.json'),JSON.stringify({schema:1,at:new Date().toISOString(),allBeforeAndAfterMatch:true,files:rows},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({allBeforeAndAfterMatch:true,files:rows.length}));

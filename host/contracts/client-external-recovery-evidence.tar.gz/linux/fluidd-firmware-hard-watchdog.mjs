import {readFile,writeFile} from 'node:fs/promises';
import {setTimeout as delay} from 'node:timers/promises';
const out='/home/dek02/.codex/worktrees/supervisor-group-compat/evidence/client-external-fault/fluidd-firmware-hard-watchdog.json',deadline=1792067256973;
const identity=async pid=>{try{const text=await readFile('/proc/'+pid+'/stat','utf8'),f=text.slice(text.lastIndexOf(')')+2).split(' ');return {pid:Number(pid),parent:Number(f[1]),startTicks:f[19],state:f[0]};}catch{return null;}};
const root=await identity(361906);if(!root)throw Error('Original scene runner absent');const command=(await readFile('/proc/'+root.pid+'/cmdline')).toString();if(!command.includes('client-fault-runner.ts')||!command.includes('fluidd'))throw Error('Unexpected runner identity');
const known=new Map([[root.pid,root]]),events=[];let stage=0;
await writeFile(out,JSON.stringify({root,deadline,watchdogPid:process.pid,status:'observing'})+'\n',{flag:'wx'});
async function census(){for(const old of [...known.values()]){const live=await identity(old.pid);if(!live||live.startTicks!==old.startTicks||live.state==='Z')continue;let children=[];try{children=(await readFile('/proc/'+old.pid+'/task/'+old.pid+'/children','utf8')).trim().split(/\s+/).filter(Boolean);}catch{}for(const pid of children){if(known.has(Number(pid)))continue;const child=await identity(pid);if(child)known.set(child.pid,child);if(known.size>128)throw Error('Owned fixture process census exceeded bound');}}
 const active=[];for(const old of known.values()){const live=await identity(old.pid);if(live?.startTicks===old.startTicks&&live.state!=='Z')active.push(live);}return active;}
let active=[];
while(Date.now()<deadline){active=await census();if(!active.length)break;const now=Date.now(),signal=now>=deadline-1000?'SIGKILL':now>=deadline-5000?'SIGTERM':null;if(signal&&stage<(signal==='SIGKILL'?2:1)){stage=signal==='SIGKILL'?2:1;for(const old of active.toReversed()){const live=await identity(old.pid);if(live?.startTicks===old.startTicks)try{process.kill(old.pid,signal);events.push({pid:old.pid,startTicks:old.startTicks,signal,at:Date.now()});}catch{}}}await delay(200);}
active=await census();await writeFile(out,JSON.stringify({root,deadline,watchdogPid:process.pid,status:active.length?'residual-failure':'closed',stage,events,remaining:active,ended:Date.now()},null,2)+'\n');if(active.length)process.exitCode=1;

import {readFile,writeFile,mkdir,cp,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {join} from 'node:path';
import {spawnSync} from 'node:child_process';
import {inspectAcceptanceBundle} from '/home/dek02/.codex/worktrees/supervisor-group-compat/ANYRAID-KLIPPER/host/test/helpers/acceptance-bundle.ts';
const base='/home/dek02/.codex/worktrees/supervisor-group-compat',tree=join(base,'ANYRAID-KLIPPER'),out=join(base,'evidence/client-external-fault');
const hash=data=>createHash('sha256').update(data).digest('hex'),files=[];
for(const path of ['host/test/helpers/compiled-client-host.ts','host/acceptance/client-fault-runner.ts','host/acceptance/client-external-fault.test.ts']){const data=await readFile(join(tree,path));await mkdir(join(out,'facilities-inputs',path,'..'),{recursive:true});await writeFile(join(out,'facilities-inputs',path),data,{flag:'wx'});files.push({path,bytes:data.length,sha256:hash(data)});}
const product=await inspectAcceptanceBundle(join(base,'service-info-parallel-product'));if(product.manifestSha256!=='cc312dc2c23dcdca94c44438c1503c1dde873da0943765062a3fe0254cbdf3a6'||product.dependenciesSha256!=='0b53079c853e4894141cf231e68b278c04de0db39fc26ea8e6326742f2e01fd4')throw Error('Locked product changed');
const remaining=[];for(const pid of await readdir('/proc'))if(/^\d+$/.test(pid))try{const bytes=await readFile('/proc/'+pid+'/cmdline'),text=bytes.toString();if((text.includes('client-fault-runner.ts')||text.includes('client-external-fault.test.ts')||text.includes('client-probe.test.ts')||text.includes('anyraid-client-external-'))&&!text.includes('seal-facilities.mjs'))remaining.push({pid:Number(pid),commandSha256:hash(bytes)});}catch{}
await writeFile(join(out,'facilities-final-identities.json'),JSON.stringify({files,product:{path:product.path,manifestSha256:product.manifestSha256,dependenciesSha256:product.dependenciesSha256},remainingMatchingProcesses:remaining,noBrowserAcceptance:true,noNativeRebuild:true},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({files,remainingMatchingProcesses:remaining}));

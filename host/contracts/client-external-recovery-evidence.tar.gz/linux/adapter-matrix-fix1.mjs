import {spawn} from 'node:child_process';
import {readFile,writeFile,mkdir,cp,symlink,rm,lstat} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {buildProductHost} from '/home/dek02/.codex/worktrees/supervisor-group-compat/ANYRAID-KLIPPER/host/scripts/build-product-host.ts';
import {inspectAcceptanceBundle} from '/home/dek02/.codex/worktrees/supervisor-group-compat/ANYRAID-KLIPPER/host/test/helpers/acceptance-bundle.ts';
const base='/home/dek02/.codex/worktrees/supervisor-group-compat',tree=join(base,'ANYRAID-KLIPPER'),out=join(base,'evidence/client-external-fault'),app=join(base,'client-reset-product'),independent=join(base,'client-reset-independent-fix1'),actual=join(base,'client-reset-product-tests-fix1'),baseline=join(base,'service-info-parallel-product');
const minimum=join(base,'node26.9/node-v26.9.0-linux-x64/bin/node'),node=process.execPath,hash=data=>createHash('sha256').update(data).digest('hex'),sha=async path=>hash(await readFile(path));
const freeze=JSON.parse(await readFile(join(out,'adapter-source-freeze-fix1.json'),'utf8')),changed=freeze.files.at(-1),changedPath=join(tree,changed.path),data=await readFile(join(out,basename(changed.path)));
if(await sha(changedPath)!==changed.beforeSha256||hash(data)!==changed.sha256)throw Error('Test fix identity mismatch');await writeFile(changedPath,data);
for(const row of freeze.files)if(await sha(join(tree,row.path))!==row.sha256)throw Error('Frozen input mismatch');
await writeFile(join(out,'adapter-fix1-transfer.json'),JSON.stringify({beforeAndAfterMatch:true,...freeze},null,2)+'\n',{flag:'wx'});
async function run(label,args,cwd=tree,extra={},limit=180){
 const command=[...args],started=Date.now(),log=join(out,label+'.log'),stream=(await import('node:fs')).createWriteStream(log,{flags:'wx'}),child=spawn(command[0],command.slice(1),{cwd,env:{...process.env,...extra},stdio:['ignore','pipe','pipe'],detached:true});child.stdout.pipe(stream,{end:false});child.stderr.pipe(stream,{end:false});let timedOut=false,error;
 const timer=setTimeout(()=>{timedOut=true;try{process.kill(-child.pid,'SIGTERM');}catch{}},limit*1000),force=setTimeout(()=>{if(child.exitCode===null&&child.signalCode===null)try{process.kill(-child.pid,'SIGKILL');}catch{}},limit*1000+5000);child.once('error',value=>{error=String(value);});
 await writeFile(join(out,label+'-running.json'),JSON.stringify({command,cwd,pid:child.pid,started,limitSeconds:limit},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({stage:label,pid:child.pid,log}));
 const result=await new Promise(resolve=>child.once('close',(code,signal)=>resolve({code,signal})));clearTimeout(timer);clearTimeout(force);await new Promise(resolve=>stream.end(resolve));const receipt={command,cwd,pid:child.pid,...result,timedOut,error,elapsedMs:Date.now()-started,log};await writeFile(join(out,label+'.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));if(result.code!==0||timedOut||error)throw Error('Failed stage '+label);
}
const identity=await inspectAcceptanceBundle(app);if(identity.manifestSha256!=='cd91f2e3242a2cd392e8489f7026fd3cd730470ec8cf03d9113332546cfc67d3')throw Error('Candidate product changed');
await run('adapter-source-fixed-file',[node,'--test','--test-reporter=tap','host/test/machine-recovery-journal.test.ts']);
const selectors=['product-host-api','product-print-api','native-request-scope','product-host-control','machine-recovery-journal'],source=selectors.map(name=>'host/test/'+name+'.test.ts'),compiled=source.map(path=>path.replace(/\.ts$/,'.js'));
const env={ANYRAID_ACCEPTANCE_BUNDLE:app,ANYRAID_ACCEPTANCE_MANIFEST_SHA256:identity.manifestSha256,ANYRAID_ACCEPTANCE_DEPENDENCIES_SHA256:identity.dependenciesSha256,ANYRAID_CLIENT_FIXED_ASSETS:'/home/dek02/.cache/codex/tmp/anyraid-fixed-frontends/fluidd-1.37.6'};
await run('adapter-independent-emit-fix1',[node,'host/scripts/run-typescript.ts','-p','host/tsconfig.json','--noEmit','false','--noEmitOnError','true','--rewriteRelativeImportExtensions','true','--rootDir',tree,'--outDir',independent]);
const inventory=JSON.parse(await readFile(join(app,'build-info.json'),'utf8')),js=Object.keys(inventory.files).filter(p=>p.endsWith('.js'));for(const p of js)if(await sha(join(independent,p))!==inventory.files[p])throw Error('Independent emit differs: '+p);await writeFile(join(out,'adapter-independent-js-match-fix1.json'),JSON.stringify({manifestSha256:identity.manifestSha256,matched:js.length,files:Object.fromEntries(js.map(p=>[p,inventory.files[p]]))},null,2)+'\n',{flag:'wx'});
await cp(join(app,'package.json'),join(independent,'package.json'));await symlink(join(app,'node_modules'),join(independent,'node_modules'),'dir');await cp(join(app,'host/assets'),join(independent,'host/assets'),{recursive:true});await cp(join(app,'host/build'),join(independent,'host/build'),{recursive:true});await cp(join(tree,'host/test/helpers/pty.c'),join(independent,'host/test/helpers/pty.c'));
await cp(independent,actual,{recursive:true,verbatimSymlinks:true});const actualSource=join(actual,'host/src');if(!actualSource.startsWith(actual+'/'))throw Error('Unsafe generated target');await rm(actualSource,{recursive:true});await symlink(join(app,'host/src'),actualSource,'dir');
for(const p of js.filter(p=>p.startsWith('scripts/'))){await rm(join(actual,p));await symlink(join(app,p),join(actual,p));}
const hook=join(out,'adapter-deny-ts-fix1.mjs');await writeFile(hook,"import {registerHooks} from 'node:module';registerHooks({resolve(specifier,context,next){if(/[.](?:ts|mts|cts)(?:[?#]|$)/u.test(specifier))throw Error('TypeScript loading forbidden: '+specifier);return next(specifier,context);}});\n",{flag:'wx'});const strict={...env,NODE_OPTIONS:'--no-experimental-strip-types --import '+hook,NODE_PATH:''};
await run('adapter-independent-fixed-file',[node,'--test','--test-reporter=tap','host/test/machine-recovery-journal.test.js'],independent,strict);
await run('adapter-product-unit-fix1',[node,'--test','--test-concurrency=1','--test-reporter=tap',...compiled],actual,strict);
await run('adapter-product-external-fix1',[node,'--test','--test-reporter=tap','host/acceptance/client-external-fault.test.js'],actual,strict);
await run('adapter-minimum-source-fix1',[minimum,'--test','--test-concurrency=1','--test-reporter=tap',...source],tree,env);
await run('adapter-minimum-product-fix1',[minimum,'--test','--test-concurrency=1','--test-reporter=tap',...compiled],actual,strict);
await run('adapter-minimum-external-fix1',[minimum,'--test','--test-reporter=tap','host/acceptance/client-external-fault.test.js'],actual,strict);
for(const row of freeze.files)if(await sha(join(tree,row.path))!==row.sha256)throw Error('Source changed after matrix');
await writeFile(join(out,'adapter-matrix-final-fix1.json'),JSON.stringify({identity,sourceFilesMatched:freeze.files.length,baseline:await inspectAcceptanceBundle(baseline),completed:Date.now()},null,2)+'\n',{flag:'wx'});

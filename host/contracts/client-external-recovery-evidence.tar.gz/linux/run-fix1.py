import subprocess,pathlib,time,json,os,signal
base=pathlib.Path('/home/dek02/.codex/worktrees/supervisor-group-compat');tree=base/'ANYRAID-KLIPPER';out=base/'evidence/client-external-fault'
node='/home/dek02/.cache/codex/tmp/legacy-install-oct14/node26.11.1/node-v26.11.1-linux-x64/bin/node'
env={**os.environ,'ANYRAID_ACCEPTANCE_BUNDLE':str(base/'service-info-parallel-product'),'ANYRAID_ACCEPTANCE_MANIFEST_SHA256':'cc312dc2c23dcdca94c44438c1503c1dde873da0943765062a3fe0254cbdf3a6','ANYRAID_ACCEPTANCE_DEPENDENCIES_SHA256':'0b53079c853e4894141cf231e68b278c04de0db39fc26ea8e6326742f2e01fd4','ANYRAID_CLIENT_FIXED_ASSETS':'/home/dek02/.cache/codex/tmp/anyraid-fixed-frontends/fluidd-1.37.6'}
for label,files,limit in [('external-fix1',['host/acceptance/client-external-fault.test.ts'],180)]:
 cmd=[node,'--test','--test-concurrency=1','--test-reporter=tap',*files];start=time.time();log=out/(label+'.log')
 with log.open('xb') as stream:
  child=subprocess.Popen(cmd,cwd=tree,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  (out/(label+'-running.json')).write_text(json.dumps({'pid':child.pid,'command':cmd,'limitSeconds':limit,'started':start}))
  timed=False
  try:code=child.wait(timeout=limit)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(child.pid,signal.SIGTERM)
   try:code=child.wait(timeout=8)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
 (out/(label+'.json')).write_text(json.dumps({'command':cmd,'pid':child.pid,'exitCode':code,'timeout':timed,'elapsedSeconds':time.time()-start,'log':str(log)},indent=2))

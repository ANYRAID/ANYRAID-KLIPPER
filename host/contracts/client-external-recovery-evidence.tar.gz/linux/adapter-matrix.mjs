import {spawn} from 'node:child_process';
import {readFile,writeFile,mkdir,cp,symlink,rm,lstat} from 'node:fs/promises';
import {join,basename} from 'node:path';
import {createHash} from 'node:crypto';
import {buildProductHost} from '/home/dek02/.codex/worktrees/supervisor-group-compat/ANYRAID-KLIPPER/host/scripts/build-product-host.ts';
import {inspectAcceptanceBundle} from '/home/dek02/.codex/worktrees/supervisor-group-compat/ANYRAID-KLIPPER/host/test/helpers/acceptance-bundle.ts';
const base='/home/dek02/.codex/worktrees/supervisor-group-compat',tree=join(base,'ANYRAID-KLIPPER'),out=join(base,'evidence/client-external-fault'),app=join(base,'client-reset-product'),independent=join(base,'client-reset-independent'),actual=join(base,'client-reset-product-tests'),baseline=join(base,'service-info-parallel-product');
const minimum=join(base,'node26.9/node-v26.9.0-linux-x64/bin/node'),node=process.execPath,hash=data=>createHash('sha256').update(data).digest('hex'),sha=async path=>hash(await readFile(path));
const freeze=JSON.parse(await readFile(join(out,'adapter-source-freeze.json'),'utf8'));
for(const row of freeze.files){const p=join(tree,row.path),data=await readFile(join(out,basename(row.path)));if(await sha(p)!==row.beforeSha256||hash(data)!==row.sha256||data.length!==row.bytes)throw Error('Source transfer identity mismatch: '+row.path);}
for(const row of freeze.files)await writeFile(join(tree,row.path),await readFile(join(out,basename(row.path))));
await writeFile(join(out,'adapter-transfer.json'),JSON.stringify({beforeAndAfterMatch:true,...freeze},null,2)+'\n',{flag:'wx'});
if(await sha(join(out,'external-reset-performance-registration.json'))!=='081bb6fb99f804a4b0e8dff8c56f425e4fcfbf9021bd072dbba9335662e3a669')throw Error('Performance registration changed');
const native=JSON.parse(await readFile(join(baseline,'host/build/native-build-info.json'),'utf8'));
for(const [p,h]of Object.entries(native.sources))if(await sha(join(tree,p))!==h)throw Error('Native input mismatch: '+p);
for(const [p,h]of Object.entries(native.outputs))if(await sha(join(baseline,'host/build',p))!==h)throw Error('Native output mismatch: '+p);
await writeFile(join(out,'adapter-native-reuse.json'),JSON.stringify({source:baseline,inputsMatched:Object.keys(native.sources).length,outputsMatched:Object.keys(native.outputs).length,rebuilt:false,metadata:native},null,2)+'\n',{flag:'wx'});
async function run(label,args,cwd=tree,extra={},limit=180){
 const command=[...args],started=Date.now(),log=join(out,label+'.log'),stream=(await import('node:fs')).createWriteStream(log,{flags:'wx'}),child=spawn(command[0],command.slice(1),{cwd,env:{...process.env,...extra},stdio:['ignore','pipe','pipe'],detached:true});child.stdout.pipe(stream,{end:false});child.stderr.pipe(stream,{end:false});let timedOut=false,error;
 const timer=setTimeout(()=>{timedOut=true;try{process.kill(-child.pid,'SIGTERM');}catch{}},limit*1000),force=setTimeout(()=>{if(child.exitCode===null&&child.signalCode===null)try{process.kill(-child.pid,'SIGKILL');}catch{}},limit*1000+5000);child.once('error',value=>{error=String(value);});
 await writeFile(join(out,label+'-running.json'),JSON.stringify({command,cwd,pid:child.pid,started,limitSeconds:limit},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({stage:label,pid:child.pid,log}));
 const result=await new Promise(resolve=>child.once('close',(code,signal)=>resolve({code,signal})));clearTimeout(timer);clearTimeout(force);await new Promise(resolve=>stream.end(resolve));const receipt={command,cwd,pid:child.pid,...result,timedOut,error,elapsedMs:Date.now()-started,log};await writeFile(join(out,label+'.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));if(result.code!==0||timedOut||error)throw Error('Failed stage '+label);
}
await run('adapter-linux-typecheck',[node,'host/scripts/run-typescript.ts','-p','host/tsconfig.json']);
const selectors=['product-host-api','product-print-api','native-request-scope','product-host-control','machine-recovery-journal'],source=selectors.map(name=>'host/test/'+name+'.test.ts'),compiled=source.map(path=>path.replace(/\.ts$/,'.js'));
await run('adapter-linux-source',[node,'--test','--test-concurrency=1','--test-reporter=tap',...source]);
for(const p of [app,independent,actual]){try{await lstat(p);throw Error('New matrix target already exists: '+p);}catch(error){if(error.code!=='ENOENT')throw error;}}
await writeFile(join(out,'adapter-build-running.json'),JSON.stringify({pid:process.pid,app,started:Date.now(),nativeReuse:baseline},null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({stage:'adapter-build',pid:process.pid,app}));
await buildProductHost(app,undefined,join(baseline,'host/build'));await cp(join(baseline,'node_modules'),join(app,'node_modules'),{recursive:true,verbatimSymlinks:true,errorOnExist:true,force:false});
const identity=await inspectAcceptanceBundle(app);await writeFile(join(out,'adapter-product-identity.json'),JSON.stringify(identity,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({stage:'adapter-build-ready',identity}));
const env={ANYRAID_ACCEPTANCE_BUNDLE:app,ANYRAID_ACCEPTANCE_MANIFEST_SHA256:identity.manifestSha256,ANYRAID_ACCEPTANCE_DEPENDENCIES_SHA256:identity.dependenciesSha256,ANYRAID_CLIENT_FIXED_ASSETS:'/home/dek02/.cache/codex/tmp/anyraid-fixed-frontends/fluidd-1.37.6'};
await run('adapter-independent-emit',[node,'host/scripts/run-typescript.ts','-p','host/tsconfig.json','--noEmit','false','--noEmitOnError','true','--rewriteRelativeImportExtensions','true','--rootDir',tree,'--outDir',independent]);
const inventory=JSON.parse(await readFile(join(app,'build-info.json'),'utf8')),js=Object.keys(inventory.files).filter(p=>p.endsWith('.js'));for(const p of js)if(await sha(join(independent,p))!==inventory.files[p])throw Error('Independent emit differs: '+p);await writeFile(join(out,'adapter-independent-js-match.json'),JSON.stringify({manifestSha256:identity.manifestSha256,matched:js.length,files:Object.fromEntries(js.map(p=>[p,inventory.files[p]]))},null,2)+'\n',{flag:'wx'});
await cp(join(app,'package.json'),join(independent,'package.json'));await symlink(join(app,'node_modules'),join(independent,'node_modules'),'dir');await cp(join(app,'host/assets'),join(independent,'host/assets'),{recursive:true});await cp(join(app,'host/build'),join(independent,'host/build'),{recursive:true});await cp(join(tree,'host/test/helpers/pty.c'),join(independent,'host/test/helpers/pty.c'));
await cp(independent,actual,{recursive:true,verbatimSymlinks:true});const actualSource=join(actual,'host/src');if(!actualSource.startsWith(actual+'/'))throw Error('Unsafe generated target');await rm(actualSource,{recursive:true});await symlink(join(app,'host/src'),actualSource,'dir');
for(const p of js.filter(p=>p.startsWith('scripts/'))){await rm(join(actual,p));await symlink(join(app,p),join(actual,p));}
const hook=join(out,'adapter-deny-ts.mjs');await writeFile(hook,"import {registerHooks} from 'node:module';registerHooks({resolve(specifier,context,next){if(/[.](?:ts|mts|cts)(?:[?#]|$)/u.test(specifier))throw Error('TypeScript loading forbidden: '+specifier);return next(specifier,context);}});\n",{flag:'wx'});const strict={...env,NODE_OPTIONS:'--no-experimental-strip-types --import '+hook,NODE_PATH:''};
await run('adapter-independent-unit',[node,'--test','--test-concurrency=1','--test-reporter=tap',...compiled],independent,strict);
await run('adapter-product-unit',[node,'--test','--test-concurrency=1','--test-reporter=tap',...compiled],actual,strict);
await run('adapter-product-external',[node,'--test','--test-reporter=tap','host/acceptance/client-external-fault.test.js'],actual,strict);
await run('adapter-minimum-source',[minimum,'--test','--test-concurrency=1','--test-reporter=tap',...source],tree,env);
await run('adapter-minimum-product',[minimum,'--test','--test-concurrency=1','--test-reporter=tap',...compiled],actual,strict);
await run('adapter-minimum-external',[minimum,'--test','--test-reporter=tap','host/acceptance/client-external-fault.test.js'],actual,strict);
for(const row of freeze.files)if(await sha(join(tree,row.path))!==row.sha256)throw Error('Source changed after matrix');
await writeFile(join(out,'adapter-matrix-final.json'),JSON.stringify({identity,sourceFilesMatched:freeze.files.length,baseline:await inspectAcceptanceBundle(baseline),completed:Date.now()},null,2)+'\n',{flag:'wx'});

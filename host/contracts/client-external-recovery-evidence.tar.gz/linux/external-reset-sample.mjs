import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {setTimeout as delay} from 'node:timers/promises';
import {createClientFaultSession} from '/home/dek02/.codex/worktrees/supervisor-group-compat/ANYRAID-KLIPPER/host/acceptance/client-fault-runner.ts';
const mode=process.argv[2];assert(['canonical','script'].includes(mode));const began=performance.now();let session,cookie='',row,error;
async function request(path,method='GET',body){const started=performance.now(),response=await fetch(session.origin+path,{method,headers:{origin:session.origin,...cookie?{cookie}:{},...body instanceof FormData?{}:{'content-type':'application/json'}},body:body===undefined?undefined:body instanceof FormData?body:JSON.stringify(body),signal:AbortSignal.timeout(15000)}),text=await response.text();let value;try{value=JSON.parse(text);}catch{value=text;}return {code:response.status,value,cookie:response.headers.get('set-cookie')?.split(';')[0],ms:performance.now()-started};}
async function get(path){const result=await request(path);assert.equal(result.code,200,JSON.stringify(result));return result.value.result;}
async function post(path,body){const result=await request(path,'POST',body);assert.equal(result.code,200,JSON.stringify(result));return result;}
async function until(check,label){const deadline=performance.now()+30000;while(!await check()){assert(performance.now()<deadline,label);await delay(20);}}
try{
 const task=await readFile('/home/dek02/.cache/codex/tmp/client-browser-long-r39-oct13.gcode');assert.equal(task.length,18785);assert.equal(createHash('sha256').update(task).digest('hex'),'12dfa06ce998ed9d72e3107c5fee40141cc51df5c72fed2b0625229c45ab077b');
 session=await createClientFaultSession('/home/dek02/.cache/codex/tmp/anyraid-fixed-frontends/fluidd-1.37.6',18428,18430,value=>console.log('FIXTURE '+JSON.stringify(value)));
 const login=await post('/_client/session',{username:'operator',password:'client-test-only'});assert(login.cookie);cookie=login.cookie;
 const form=new FormData();form.append('file',new Blob([task]),'external-budget.gcode');form.append('root','gcodes');const uploaded=await request('/server/files/upload','POST',form);assert.equal(uploaded.code,201);assert.equal(uploaded.value.result.print_started,false);
 await post('/printer/gcode/script',{script:'G28'});await until(async()=>(await get('/server/info')).native_host.homed_axes.includes('x'),'setup homing');
 await post('/printer/print/start',{filename:'external-budget.gcode'});await until(async()=>(await get('/printer/print/status')).state==='printing','setup active print');const active=await get('/printer/print/status'),requestId=active.request.request_id;assert(requestId);const setupMs=performance.now()-began,steps=[];
 const actionBegan=performance.now();
 if(mode==='canonical'){
  let start=performance.now(),state=await get('/printer/print/status');steps.push({label:'status',ms:performance.now()-start});assert.equal(state.request.request_id,requestId);
  steps.push({label:'cancel',ms:(await post('/printer/print/cancel',{request_id:requestId,state_token:state.state_token})).ms});
  start=performance.now();state=await get('/printer/print/status');steps.push({label:'cancelled-status',ms:performance.now()-start});assert.equal(state.state,'cancelled');assert.equal(state.request.request_id,requestId);
  steps.push({label:'reset',ms:(await post('/printer/print/reset',{request_id:requestId,state_token:state.state_token})).ms});
 }else steps.push({label:'script',ms:(await post('/printer/gcode/script',{script:'SDCARD_RESET_FILE'})).ms});
 const predicateBegan=performance.now(),terminal=await get('/printer/print/status?request_id='+requestId);assert.equal(terminal.current.state,'idle');assert.equal(terminal.current.request,null);assert.equal(terminal.record.request.request_id,requestId);assert.equal(terminal.record.state,'cancelled');
 const actionMs=performance.now()-actionBegan;steps.push({label:'terminal-predicate',ms:performance.now()-predicateBegan});row={mode,node:process.version,setupMs,actionMs,steps,requestId,terminal:{state:terminal.current.state,record:terminal.record.state},manifestSha256:process.env.ANYRAID_ACCEPTANCE_MANIFEST_SHA256};
}catch(value){error=String(value?.stack??value);}
const cleanupBegan=performance.now();if(session)try{await session.close();if(!error)await session.dispose();}catch(value){error=[error,String(value?.stack??value)].filter(Boolean).join('\n');}const cleanupMs=performance.now()-cleanupBegan;
console.log('EXTERNAL_RESET_BENCH_RESULT '+JSON.stringify({row,error,cleanupMs,totalMs:performance.now()-began}));if(error)process.exitCode=1;

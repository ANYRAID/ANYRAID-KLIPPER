import {spawn} from 'node:child_process';
import {createWriteStream} from 'node:fs';
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {setTimeout as delay} from 'node:timers/promises';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {inspectAcceptanceBundle} from '/home/dek02/.codex/worktrees/supervisor-group-compat/ANYRAID-KLIPPER/host/test/helpers/acceptance-bundle.ts';
const base='/home/dek02/.codex/worktrees/supervisor-group-compat',out=join(base,'evidence/client-external-fault'),node=join(base,'node26.9/node-v26.9.0-linux-x64/bin/node'),started=Date.now(),deadline=started+900000;
const registrationBytes=await readFile(join(out,'external-reset-performance-registration.json')),registrationSha256=createHash('sha256').update(registrationBytes).digest('hex');if(registrationSha256!=='081bb6fb99f804a4b0e8dff8c56f425e4fcfbf9021bd072dbba9335662e3a669')throw Error('Registration changed');const registration=JSON.parse(registrationBytes);
const baseline=await inspectAcceptanceBundle(join(base,'service-info-parallel-product')),candidate=await inspectAcceptanceBundle(join(base,'client-reset-product'));
if(baseline.manifestSha256!==registration.baseline.manifestSha256||baseline.dependenciesSha256!==registration.baseline.dependenciesSha256||candidate.manifestSha256!=='cd91f2e3242a2cd392e8489f7026fd3cd730470ec8cf03d9113332546cfc67d3'||candidate.dependenciesSha256!==baseline.dependenciesSha256)throw Error('Frozen products changed');
await writeFile(join(out,'external-reset-performance-run-marker.json'),JSON.stringify({pid:process.pid,started,deadline,registrationSha256})+'\n',{flag:'wx'});
const proc=async pid=>{try{const raw=await readFile('/proc/'+pid+'/stat','utf8'),fields=raw.slice(raw.lastIndexOf(')')+2).split(' ');return {pid:Number(pid),group:Number(fields[2]),startTicks:fields[19],state:fields[0]};}catch{return null;}};
const group=async id=>{const members=[];for(const pid of await readdir('/proc'))if(/^\d+$/.test(pid)){const member=await proc(pid);if(member?.group===id&&member.state!=='Z')members.push(member);}return members;};
const rows=[],output=join(out,'external-reset-performance.json');let failure,current;
const save=async()=>writeFile(output,JSON.stringify({registrationSha256,registration,started,deadline,baseline:{path:baseline.path,manifestSha256:baseline.manifestSha256,dependenciesSha256:baseline.dependenciesSha256},candidate:{path:candidate.path,manifestSha256:candidate.manifestSha256,dependenciesSha256:candidate.dependenciesSha256},rows,failure},null,2)+'\n');
try{
 await save();const work=[...registration.warmups.order.map(variant=>({variant,warmup:true})),...registration.formal.order.map(variant=>({variant,warmup:false}))];
 for(let index=0;index<work.length;index++){
  if(Date.now()>=deadline-10000)throw Error('900-second driver deadline');const {variant,warmup}=work[index],bundle=variant==='B'?baseline:candidate,mode=variant==='S'?'script':'canonical',log=join(out,'external-reset-performance-row-'+String(index).padStart(2,'0')+'.log'),stream=createWriteStream(log,{flags:'wx'}),command=[node,join(out,'external-reset-sample.mjs'),mode];
  let tail='',childError;const rowStarted=Date.now(),child=spawn(command[0],command.slice(1),{cwd:join(base,'ANYRAID-KLIPPER'),env:{...process.env,ANYRAID_ACCEPTANCE_BUNDLE:bundle.path,ANYRAID_ACCEPTANCE_MANIFEST_SHA256:bundle.manifestSha256,ANYRAID_ACCEPTANCE_DEPENDENCIES_SHA256:bundle.dependenciesSha256},stdio:['ignore','pipe','pipe'],detached:true});current=child;console.log(JSON.stringify({event:'sample-start',index,variant,warmup,pid:child.pid}));
  child.stdout.on('data',bytes=>{stream.write(bytes);tail=(tail+String(bytes)).slice(-65536);});child.stderr.on('data',bytes=>stream.write(bytes));child.once('error',error=>{childError=String(error);});
  const rootIdentity=await proc(child.pid),known=new Map();let timedOut=false,cleanup;
  if(rootIdentity)known.set(child.pid,rootIdentity);
  const collect=async()=>{const anchors=await Promise.all([...known.values()].map(async old=>{const live=await proc(old.pid);return live?.startTicks===old.startTicks&&live.group===child.pid&&live.state!=='Z';}));if(anchors.some(Boolean))for(const member of await group(child.pid))known.set(member.pid,member);};
  const terminate=async()=>{timedOut=true;await collect();const rootNow=await proc(child.pid);if(rootIdentity&&rootNow?.startTicks===rootIdentity.startTicks)try{process.kill(-child.pid,'SIGTERM');}catch{};};
  const timer=setTimeout(()=>void terminate().catch(error=>{childError='Timeout census failed: '+String(error);}),Math.max(0,deadline-Date.now()-10000));
  let forceDone;const forced=new Promise(resolve=>{forceDone=resolve;});
  const force=setTimeout(async()=>{try{if(timedOut){await collect();for(const old of known.values()){const live=await proc(old.pid);if(live?.startTicks===old.startTicks&&live.group===child.pid&&live.state!=='Z')try{process.kill(old.pid,'SIGKILL');}catch{}}await delay(200);cleanup={known:[...known.values()],remaining:await group(child.pid)};}}catch(error){childError='Timeout cleanup failed: '+String(error);}finally{forceDone();}},Math.max(0,deadline-Date.now()-5000));
  const exit=await new Promise(resolve=>child.once('close',(code,signal)=>resolve({code,signal})));
  if(timedOut){await forced;if(!cleanup||cleanup.remaining.length)childError='Timed-out owned process group did not fully disappear';}else{clearTimeout(timer);clearTimeout(force);}current=undefined;await new Promise(resolve=>stream.end(resolve));const text=tail.split('\n').findLast(line=>line.startsWith('EXTERNAL_RESET_BENCH_RESULT ')),result=text?JSON.parse(text.slice('EXTERNAL_RESET_BENCH_RESULT '.length)):undefined;
  rows.push({index,variant,warmup,pid:child.pid,command,log,elapsedMs:Date.now()-rowStarted,...exit,timedOut,groupCleanup:cleanup,childError,result});await save();console.log(JSON.stringify({event:'sample-complete',index,variant,warmup,exit,actionMs:result?.row?.actionMs,error:result?.error}));if(exit.code!==0||timedOut||childError||!result?.row||result.error)throw Error('Failed variant '+variant+' at row '+index);
 }
 const median=values=>{const sorted=values.toSorted((a,b)=>a-b),at=sorted.length/2;return (sorted[at-1]+sorted[at])/2;},medians={};for(const variant of ['B','A','S']){const samples=rows.filter(row=>row.variant===variant&&!row.warmup);if(samples.length!==8)throw Error('Registered sample count mismatch');medians[variant]=median(samples.map(row=>row.result.row.actionMs));}
 const comparisons={canonicalCandidateOverBaseline:medians.A/medians.B,scriptOverCandidateCanonical:medians.S/medians.A},passed=comparisons.canonicalCandidateOverBaseline<=1.5&&comparisons.scriptOverCandidateCanonical<=1.5;
 for(const bundle of [baseline,candidate]){const final=await inspectAcceptanceBundle(bundle.path);if(final.manifestSha256!==bundle.manifestSha256||final.dependenciesSha256!==bundle.dependenciesSha256)throw Error('Product changed during sampling');}
 await writeFile(join(out,'external-reset-performance-summary.json'),JSON.stringify({registrationSha256,medians,comparisons,passed,completed:Date.now(),elapsedMs:Date.now()-started,scope:registration.scope},null,2)+'\n',{flag:'wx'});if(!passed)throw Error('Registered 1.5 budget exceeded');

}catch(error){failure=String(error?.stack??error);process.exitCode=1;}finally{if(current&&current.exitCode===null&&current.signalCode===null)try{process.kill(-current.pid,'SIGTERM');}catch{}await save();await writeFile(join(out,'external-reset-performance-receipt.json'),JSON.stringify({pid:process.pid,node:process.version,started,deadline,ended:Date.now(),elapsedMs:Date.now()-started,exitCode:process.exitCode??0,failure,rowCount:rows.length},null,2)+'\n',{flag:'wx'});}

import {spawn} from 'node:child_process';
import {mkdtemp,writeFile,chmod,rm,readFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const base='/home/dek02/.codex/worktrees/supervisor-group-compat',e=join(base,'evidence/none');
const before=join(base,'product'),after=join(base,'none-product');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const {inspectAcceptanceBundle}=await import(pathToFileURL(join(base,'ANYRAID-KLIPPER/host/test/helpers/acceptance-bundle.ts')));
const identities=[await inspectAcceptanceBundle(before),await inspectAcceptanceBundle(after)];
if(identities[0].manifestSha256!=='f6b2dd80d00b56bd95bb7ff86e88d87615a5f845996faa9bc76f57e0afc230a1'||identities[1].manifestSha256!=='85e233de1fd8e90e72fe9324e9b57cea984646ec731f26f5641761ad17349bd8')throw Error('Package identity changed');
if(identities[0].dependenciesSha256!==identities[1].dependenciesSha256)throw Error('Dependency identity mismatch');
const registration=JSON.parse(await readFile(join(e,'none-performance-workload-freeze.json'),'utf8'));
const inputs=JSON.parse(await readFile(join(e,'none-unchanged-motion-inputs.json'),'utf8'));
for(const row of inputs.files){const bytes=await readFile(join(base,'ANYRAID-KLIPPER',row.path));if(bytes.length!==row.bytes||sha(bytes)!==row.sha256)throw Error('Input changed: '+row.path);}
const frozen={node:process.execPath,nodeSha256:sha(await readFile(process.execPath)),version:process.version,registrationSha256:sha(await readFile(join(e,'none-performance-workload-freeze.json'))),identities,inputs:inputs.files.length,scriptSha256:sha(await readFile(new URL(import.meta.url))),apiScriptSha256:sha(await readFile(join(e,'bench-linux-none-api.mts'))),scope:'Pre-sampling identity. API shared current registry/control and old/current compiled handlers. Cold import existing724 baseline versus fresh725 product, same absolute Node, no JIT/CPU change. Native reused after input/output proof; no full42/28 or physical proof.'};
await writeFile(join(e,'linux-performance-pre-sampling.json'),JSON.stringify(frozen,null,2)+'\n');
async function child(args){return await new Promise((resolve,reject)=>{let stdout='',stderr='';const start=performance.now();const p=spawn(process.execPath,args,{env:{...process.env,NODE_OPTIONS:''},stdio:['ignore','pipe','pipe']});const timer=setTimeout(()=>p.kill('SIGKILL'),15000);p.stdout.on('data',b=>{stdout+=b;if(stdout.length>65536)p.kill('SIGKILL');});p.stderr.on('data',b=>{stderr+=b;if(stderr.length>65536)p.kill('SIGKILL');});p.once('error',reject);p.once('close',async(code,signal)=>{clearTimeout(timer);const receipt={code,signal,stdout,stderr,elapsedMs:performance.now()-start};if(code!==0){await writeFile(join(e,'linux-performance-child-failure.json'),JSON.stringify({args,...receipt},null,2)+'\n');reject(Object.assign(Error('Performance child failed'),{receipt}));}else resolve(receipt);});});}
const api=await child([join(e,'bench-linux-none-api.mts')]);await writeFile(join(e,'linux-api-performance-execution.json'),JSON.stringify(api,null,2)+'\n');
const rows=[],targets=[before,after];
for(let pair=0;pair<registration.defaultImport.freshChildrenPerVariant;pair++){
 for(const variant of pair%2===0?[0,1]:[1,0]){
  const url=pathToFileURL(join(targets[variant],registration.defaultImport.entry)).href;
  const result=await child(['--no-experimental-strip-types','--input-type=module','-e',"const start=performance.now();await import(process.argv[1]);console.log(JSON.stringify({importMs:performance.now()-start}));",url]);
  rows.push({pair,variant,importMs:JSON.parse(result.stdout).importMs,wallMs:result.elapsedMs});await writeFile(join(e,'linux-cold-import-partial.json'),JSON.stringify({rows,complete:false},null,2));
 }
}
const median=values=>[...values].sort((a,b)=>a-b)[Math.floor(values.length/2)];
const medians=[0,1].map(v=>median(rows.filter(r=>r.variant===v).map(r=>r.importMs)));
const cold={node:process.version,rows,mediansMs:medians,ratio:medians[1]/medians[0],limit:1.5,pass:medians[1]/medians[0]<=1.5,scope:'28 fresh children per variant AB/BA. Cold module import only, not full bootstrap/HTTP/D-Bus/printing or original28 startup budget.'};
await writeFile(join(e,'linux-default-import-performance.json'),JSON.stringify(cold,null,2)+'\n');
const {nonePowerCommand}=await import(pathToFileURL(join(after,'host/src/moonraker/none-machine-control.js')));
const bin=await mkdtemp(join(tmpdir(),'none-power-cost-'));const commands=[];
try{
 for(const name of ['systemctl','reboot','poweroff','halt']){const file=join(bin,name);await writeFile(file,'#!'+process.execPath+'\nprocess.exitCode=0;\n');await chmod(file,0o700);}
 for(const name of ['systemctl','reboot','poweroff','halt']){const args=name==='systemctl'?['--no-pager','--no-ask-password','--no-block','halt']:[],start=performance.now();await nonePowerCommand(name,args,new AbortController().signal,undefined,bin);commands.push({binary:name,args,elapsedMs:performance.now()-start});}
}finally{await rm(bin,{recursive:true,force:true});}
await writeFile(join(e,'linux-fake-power-absolute-cost.json'),JSON.stringify({node:process.version,commands,scope:'One child close per fixed fake CLI name, PATH contains only four fake executables and absolute Node shebangs. Absolute cold command helper cost, no guard/retirement/HTTP/OS action and no speed claim.'},null,2)+'\n');
const afterIdentities=[await inspectAcceptanceBundle(before),await inspectAcceptanceBundle(after)];if(JSON.stringify(identities)!==JSON.stringify(afterIdentities))throw Error('Package changed during sampling');
console.log(JSON.stringify({coldRatio:cold.ratio,coldPass:cold.pass,identitiesUnchanged:true,api:JSON.parse(api.stdout),fakeCommands:commands}));if(!cold.pass)process.exitCode=1;

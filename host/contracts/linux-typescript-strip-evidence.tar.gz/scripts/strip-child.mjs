import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {stripTypeScriptTypes} from 'node:module';
import {pathToFileURL} from 'node:url';
const file=process.argv[2],hash=b=>createHash('sha256').update(b).digest('hex');
const allowed=new Map([
 ['/home/dek02/.codex/worktrees/supervisor-group-compat/ANYRAID-KLIPPER/host/test/published-copy.test.ts','45b1506778e81c1fc478aee65d31b6937f1aa5e107c6edfe37ca09012442a78d'],
 ['/home/dek02/.codex/worktrees/supervisor-group-compat/ANYRAID-KLIPPER/host/test/ufp-archive.test.ts','f3f2642f66b676af3d36b1f0a098a01206ba706ec63002c9c8f41224c180c39e'],
]);
if(!allowed.has(file))throw Error('Unregistered input');
const input=readFileSync(file),inputSha256=hash(input);if(inputSha256!==allowed.get(file))throw Error('Input identity mismatch');
const emit=v=>process.stdout.write(JSON.stringify(v)+'\n');
emit({event:'strip-start',at:Date.now(),inputSha256,inputBytes:input.length});
try{const output=stripTypeScriptTypes(input.toString('utf8'),{mode:'strip',sourceUrl:pathToFileURL(file).href});emit({event:'strip-ok',at:Date.now(),inputSha256,outputSha256:hash(output),outputBytes:Buffer.byteLength(output)});}
catch(error){emit({event:'strip-error',at:Date.now(),inputSha256,error:{name:typeof error?.name==='string'?error.name.slice(0,80):'unknown',code:typeof error?.code==='string'&&/^[A-Z0-9_]{1,80}$/.test(error.code)?error.code:null,knownMessage:['unreachable','memory access out of bounds'].find(v=>String(error?.message).endsWith(v))??null,messageSha256:hash(String(error?.message))}});process.exitCode=1;}

# A：固定Node公开TS剥离窄诊断（待根审，未执行）

唯一out `/home/dek02/.codex/worktrees/supervisor-group-compat/evidence/exit-strip-once`，不存在才创建。只传owner/strip-child/linux-watchdog/manifest四文件至对应review。启动前只读确认无同任务负载，记录owner与guard实际live PID/startTicks及新绝对120s deadline。禁止自动重跑或更换输入求绿。

固定Node26.11.1、两入口原字节、host/package.json type module。原内置源码已从该二进制只读导出。`--check`未走目标strip路径，已静态拒绝且未执行。替代公开node:module.stripTypeScriptTypes(mode strip)归一strip-only后到相同parseTypeScript；使用pathToFileURL的file URL，匹配原ESM translator传入url形式。区别：公开入口绕开loader/cache，不加载传递模块，更不执行项目代码。原失败栈没有给出实际TS文件名；两入口只是一小部分解析输入。

固定交替24个fresh进程（每入口12），无JIT/栈/内存flag或NODE_OPTIONS变化。每进程只输出输入SHA/字节、输出SHA/字节，或有限错误name/code/两已知错误标签与messageSHA；不输出源码或一般错误正文。外owner保存exit/close/error/code/signal与<=64KiB两流，超限立即设施失败。短进程/proc身份、limits、cgroup采样立即进行，不暂停/延迟进程；遗漏/部分不可用如实记录。若捕获cgroup则保存memory.events等前后，累计计数不自动归因本次；cgroup共享计数变化也不能唯一归因此子进程。

90s拒绝新动作并TERM当前子；独立guard105s按PID/startTicks强制清理，120s绝对截止。正常owner结束后guard清理登记残留并写终态。首次失败保存即收口，不替换样本；全部24通过仅称有限未复现，不称确定性判断、修复或全测通过。任何单次失败也不直接证明硬件或资源根因。

B暂不推进，低内存sha256工作负载对本问题判别力不足；不安装工具、不自制压力框架、不运行其他负载。1735产物和产品源码均不改。当前本目录只静态准备。

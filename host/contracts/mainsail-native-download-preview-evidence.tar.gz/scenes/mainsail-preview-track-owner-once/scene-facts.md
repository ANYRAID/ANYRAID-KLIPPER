# Mainsail 原生预览有限场

- 本场仅上传合成的 1000 字节双层预览文件，未打印、归位、下载、改配置、操作队列或注入故障。
- 固定产品 cd91f2e3242a2cd392e8489f7026fd3cd730470ec8cf03d9113332546cfc67d3；依赖 0b53079c853e4894141cf231e68b278c04de0db39fc26ea8e6326742f2e01fd4；Mainsail 2.19.0；Node 26.9.0。
- 内置浏览器本次 about:blank 预检返回 Browser is not available: iab；使用独立 owned Edge、默认 sandbox 与 Playwright 默认下载所有权，没有自定义下载配置。
- 原生精确文件名单元格右键打开 View 3D。实际可见滑块圆点普通点击后，数值仍为 0，浏览器 activeElement 为该 role=slider 元素；随后实际 page.keyboard 按键逐批核对到 844 和 995。
- 08-layer1.png 显示第一层外框；09-layer2.png 显示额外的较小内框。截图和原生位置、输入字节边界共同供视觉复核。合成文件的 parser 标记不是实际切片器兼容证明。
- started=1792078837016，停止新动作=1792079317016，deadline=1792079437016；ended=1792078849801。全部清理耗时 12785ms，exit=0，cleanupErrors 为空。
- owner94468、SSH65844、tunnel32216、Edge124500 均终态。远端 root376546/watchdog376557/product376575/gateway376624 均不存在；watchdog closed/stage0/remaining=[]；本机 18434/19236 无监听。精确 startTicks 保留在各身份收据内。
- 前两场（整行宽度门禁、隐藏 role 容器定位）原证据不改。本次只证明同包 JWT 路线的实际双层预览，不代表真实设备、可信网络/TLS、完整 G1 或发布验收。历史服务重获 2.62602 > 1.5 仍失败。
- 私有 edge-profile、认证或会话数据不应纳入归档。此目录尚未封包、提交或推送。

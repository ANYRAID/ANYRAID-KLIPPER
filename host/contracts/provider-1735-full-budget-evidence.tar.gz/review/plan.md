# 原42／28对当前1735：只读适配计划，未运行

固定原704 baseline（61ab21ff／deps3624a6b3）不换成较近cd91；候选固定173565dc／deps0b53079c。184只读核三个build-info原值及14直接模块实际SHA，均与各自清单一致；旧723 e6cadde→1735有17生产JS改变、3新增，名单与直接14模块对照在remote-product-differences.json。直接模块仅auth、configured-server、native-product-machine、product-host-control四处不同，其余10处同SHA。两受测包存在，不重建／更新／安装依赖。

历史依据为system-bus-provider-evidence.tar.gz SHA568e7a76...；选择的九脚本逐bytes/SHA对evidence-manifest.json。proposal-manifest.json登记完整原／新SHA、唯一输出目录与路径替换，paths-only.patch供审：仅after导入723→1735，输出目录／startup cwd改到现任务环境；另只改summary.scope的723身份说明为1735，不改行为；原before包仍704。新目录没有bare ws解析能力，两个network脚本改到它们原先实际解析的同一个723包ws8.21.3/wrapper.mjs（SHAfe154662...），两版仍同字节，不引入新依赖或改变协议实现。auth-before、uploads-before和process-log-startup-none.js原字节完全不变。

42比较仍原3对AB／BA／AB，各14指标：
- 4鉴权route：status/file/image/anonymous-image，100000×8轮（3warm／5保留），同一request/context复用，不换成本批窄鉴权的每请求新对象。
- 6网络指标：manual/configured各HTTP200、WS500、load/listen/close30次；各3warm／11保留、每轮顺序交替。steady-state先删配置文件；相同metadata／authorize回调，无process provider。启动指标包括原load/start/close循环，不等同28项计时。
- 4上传指标：4／16MiB各direct／multipart HTTP，2warm／7保留，次序交替；source/FormData准备、验证和删除不计时，HTTP客户端同event loop。授权noop，不改成真实JWT或打印业务。
总共36个fresh benchmark子进程（每版每对4auth+1network+1uploads）。每子原timeout60s／maxBuffer4MiB，原输出以wx拒绝覆盖。对子失败即assert停；ratio超限原算法仍完成原42后写summary整体失败，不提前终止或追加样本。所有ratio<=1.5且auth<10us，不改边界。原auth只输出5保留raw；网络／上传只原摘要，不能称新增完整round原数值。

28是一个benchmark进程，先导入两包后，两版各14次factory（3warm／11保留），每轮AB／BA交替；不是28个fresh进程，不称冷模块启动。计时从factory.bootstrap开始，含control.configure(recoveryJournal)与HTTP listen；排除模块import、夹具文件准备、cleanup，保留同一原进程内模块缓存。原显式none source保持，无installation、createAdapter必须throw，不能获取MCU／真实设备。当前factory仍补systemInformation:{}，显式source继续抑制默认provider。原server.close→factory.close→control.close→rm顺序不改。外wrapper原timeout120s／maxBuffer8MiB、--no-experimental-strip-types不改；原summary在ratio<=1.5 assert前输出。28个iteration身份以run/variant/factory归属，不伪造28个PID。

缺口：原42最大1.12426、auth3.59697us和原28比1.00397均为704→723；不是1735证据。1735已验原四route绝对预算和cd91→1735窄鉴权（Node26.9），可直接引用且不重跑窄对照，但不能补原Node26.11.1、704→1735的42项或28项；这两完整候选组仍缺。默认D-Bus／安装／服务重获不在这两组内，已失败2.626022>1.5不重测，也不借这两组绿色关闭它。

待审执行外封装只负责前后身份／输出／退出：固定Node26.11.1 SHA5a7b8a3c，保持普通调度／CPU0–5和原Node flags，无NODE_OPTIONS／JOB／taskset／JIT／memory设置；环境覆盖名称仅核空，不输出秘密。先核无同项目负载、唯一新out不存在、完整两包产品清单+各自依赖摘要以及共享原ws；不清缓存。前后均复核同两包（任何变动判设施失败），不覆盖冻结1735或原704。source树／编译／安装无需改变。

原36个spawnSync子进程保持原code/signal/退出记录；外层250ms进程组身份采样可能漏短PID，不保证36个PID都捕获，不能补造或改原bench凑齐。28在单个额外benchmark PID内按原observations登记28个run/variant实例。已核GNUtimeout9.4监控run-owned.sh：870s TERM／885s KILL，900s整体收口，无780s计时。shell带TERM trap，owner正常／异常／崩溃退出后仍执行cleanup-only，只在核实guard PID/startTicks/精确参数/PGID后清理本组；TERM2s再KILL2s。任何清理信号介入使外层失败，不把残留处理写成自然退出；最终无PID须在wrapper退出后独立复核。这是外部安全上限，不延长原每子60s／startup wrapper120s期限。超时／输出cap／未完成保留失败与原始两流，不能宣称42／28已完成或新开补样。独立日志只保存本场必要身份、bench JSON和退出，不记录argv/env凭据；清理仅本场PID/ticks及新临时fixture，不删除任何旧证据。owner.mjs、run-owned.sh与launch-once.sh已准备；尚未传输／运行，待根审完整封装，不新注册指标或增加测量阶段。

本次只读探测两处shell输入末尾误带JS标记，完成只读输出后报ReferenceError；原记录保留，不能计作产品或基准失败。没有基准执行、试跑估时、服务重获采样或额外CI。

#!/bin/sh
set -u
review=/home/dek02/.codex/worktrees/supervisor-group-compat/evidence/original-budgets-1735-review
out=/home/dek02/.codex/worktrees/supervisor-group-compat/evidence/original-budgets-1735-once
test ! -e "$out" || exit 90
test ! -e "$review/timeout-result.json" || exit 91
/usr/bin/timeout --signal=TERM --kill-after=15s --verbose 870s /bin/sh "$review/run-owned.sh" > "$review/launcher.stdout.log" 2> "$review/timeout.stderr.log"
code=$?
printf '{"timeoutExitCode":%s,"endedMs":%s,"wrapperPid":%s,"scope":"Outer timeout status, separate from original benchmark and comparison results"}\n' "$code" "$(date +%s%3N)" "$$" > "$review/timeout-result.json"
exit "$code"

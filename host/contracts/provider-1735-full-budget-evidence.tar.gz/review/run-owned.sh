#!/bin/sh
set -u
review=/home/dek02/.codex/worktrees/supervisor-group-compat/evidence/original-budgets-1735-review
node=/home/dek02/.cache/codex/tmp/legacy-install-oct14/node26.11.1/node-v26.11.1-linux-x64/bin/node
trap ':' TERM INT
"$node" "$review/owner.mjs" > "$review/owner.stdout.log" 2> "$review/owner.stderr.log"
owner_code=$?
"$node" "$review/owner.mjs" --cleanup > "$review/cleanup.stdout.log" 2> "$review/cleanup.stderr.log"
cleanup_code=$?
if test "$owner_code" -ne 0; then exit "$owner_code"; fi
if test "$cleanup_code" -ne 0; then exit 95; fi
exit 0

var __rewriteRelativeImportExtension = (this && this.__rewriteRelativeImportExtension) || function (path, preserveJsx) {
    if (typeof path === "string" && /^\.\.?\//.test(path)) {
        return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function (m, tsx, d, ext, cm) {
            return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : (d + ext + "." + cm.toLowerCase() + "js");
        });
    }
    return path;
};
// Paired standard process dependencies/recovery/listener startup. No MCU ready.
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, rm } from 'node:fs/promises';
import { join, isAbsolute } from 'node:path';
import { tmpdir } from 'node:os';
import { pathToFileURL } from 'node:url';
const packages = process.argv.slice(2);
assert.equal(packages.length, 2, 'Supply original and candidate standard product directories');
assert(packages.every(isAbsolute));
const modules = await Promise.all(packages.map(async (root) => ({ factory: (await import(__rewriteRelativeImportExtension(pathToFileURL(join(root, 'host/src/runtime/native-product-machine.js')).href))).createNativeProductHostFactory, database: (await import(__rewriteRelativeImportExtension(pathToFileURL(join(root, 'host/src/moonraker/database.js')).href))).DatabaseStore, control: (await import(__rewriteRelativeImportExtension(pathToFileURL(join(root, 'host/src/runtime/product-host-control.js')).href))).ProductHostControl })));
const times = [[], []], observations = [];
for (let run = 0; run < 14; run++)
    for (const variant of run % 2 ? [1, 0] : [0, 1]) {
        const dir = await mkdtemp(join(tmpdir(), 'process-startup-budget-')), paths = { printer: join(dir, 'printer.cfg'), moon: join(dir, 'moonraker.conf'), journal: join(dir, 'jobs.sqlite'), profile: join(dir, 'machine.json') }, m = modules[variant], control = new m.control();
        let server, factory, database;
        try {
            await writeFile(paths.printer, '[mcu]\nserial: /explicit-not-acquired\n');
            await writeFile(paths.moon, '[server]\nhost: 127.0.0.1\nport: 0\n');
            await writeFile(paths.profile, JSON.stringify({ version: 1, deviceId: 'startup-budget', printerConfig: paths.printer, moonrakerConfig: paths.moon, journalPath: paths.journal, mcus: { mcu: { transport: 'uart', rts: true, leaveBootloader: false } }, machine: { enableLeadTime: .001, fanMinimumScheduleTime: .001 }, print: { motorCompletion: 'hold', startupHoming: { mode: 'home', axes: [0, 1, 2] }, parking: { parkXY: [0, 0], retract: 0, lift: 0, travelSpeed: 10, liftSpeed: 10, retractSpeed: 10 } }, limits: { maxNozzle: 300, maxBed: 130 } }));
            const signal = new AbortController().signal;
            factory = m.factory(paths.profile, { filesRoot: join(dir, 'files'), metadataRoot: join(dir, 'metadata'), dataPath: join(dir, 'private'), async createProcess() { database = await m.database.open({ path: join(dir, 'authorization.sqlite') }); return { server: { systemServices:{source:async()=>({provider:'none',available_services:[],service_state:{},instance_ids:{moonraker:'',klipper:''}})}, information: { connected: false, state: 'disconnected', components: [], failedComponents: [], directories: [], warnings: [], version: 'startup-budget', missingRequirements: [] }, database, authorization: { issuer: 'http://printer.test' } }, async release() { await database.close(); } }; }, async createAdapter() { throw new Error('Startup benchmark must not acquire a device'); } });
            const start = performance.now(), process = await factory.bootstrap(signal, control);
            server = process.server;
            await control.configure(process.recoveryJournal);
            const address = await server.start(), ms = performance.now() - start;
            assert(address.port > 0);
            observations.push({ run, variant, ms });
            if (run >= 3)
                times[variant].push(ms);
        }
        finally {
            await server?.close();
            await factory?.close();
            await control.close();
            await rm(dir, { recursive: true, force: true });
        }
    }
const results = times.map(values => { const sorted = [...values].sort((a, b) => a - b); return { rawMs: values, medianMs: sorted[5], p95Ms: sorted[10] }; }), ratio = results[1].medianMs / results[0].medianMs;
console.log(JSON.stringify({ node: process.version, packages, warmup: 3, samples: 11, startupsPerVariant: 14, alternating: true, observations, results, ratio, maximumRatio: 1.5, scope: 'Standard native process factory bootstrap, files/authorization/journals/templates/config, recovery control and actual HTTP listener. Module imports and fixture preparation excluded. Cleanup outside timing; logger worker creation and headers included. No device factory acquisition or full hardware ready; no real hardware.' }));
assert(ratio <= 1.5, 'Native process startup regression');

from pathlib import Path
import subprocess,os,json,time
evidence=Path('/home/dek02/.cache/codex/tmp/legacy-install-oct14')
host=Path('/home/dek02/.cache/codex/tmp/anyraid-moonraker-composition-integration/host')
node=evidence/'node26.11.1/node-v26.11.1-linux-x64/bin/node'
cache=Path('/home/dek02/.codex/worktrees/e068/ANYRAID-KLIPPER/host/node_modules/.cache')
allowed=sorted(os.sched_getaffinity(0));selected=allowed[0];os.sched_setaffinity(0,{selected})
env=dict(os.environ,TMPDIR='/home/dek02/.cache/codex/tmp',CARGO_BUILD_JOBS='1',CARGO=str(cache/'cargo/bin/cargo'),RUSTC=str(cache/'cargo/bin/rustc'),CARGO_HOME=str(cache/'cargo'),RUSTUP_HOME=str(cache/'rustup'),PATH=str(node.parent)+':'+str(cache/'cargo/bin')+':'+os.environ['PATH'])
files=['test/product-build.test.ts','test/product-native-build.test.ts']
for p in files:assert (host/p).is_file()
receipt={'node':'v26.11.1','allowedCpus':allowed,'selectedCpu':selected,'cargoBuildJobs':1,'scope':'Only this build/test driver inherits selected CPU; no application/default affinity setting is modified. The selected CLI test inherits it and is scoped accordingly; final package runtime tests run ordinary scheduling.','results':[]}
args=[str(node),'--test','--test-isolation=none','--test-concurrency=1','--test-reporter=tap','--test-name-pattern=^(compiled CLI uses bundled native owners and a JS profile to start and stop two real UART transports|fresh native build uses explicit C and Rust tools without Python, binds sources and preserves existing destinations)$',*files]
begin=time.monotonic()
with (evidence/'ci-affinity-two-repair-26.11.1.log').open('x') as log:r=subprocess.run(args,cwd=host,env=env,stdout=log,stderr=subprocess.STDOUT)
(evidence/'ci-affinity-two-repair-26.11.1.status').write_text(str(r.returncode)+'\n');receipt['results'].append({'stage':'two previously failing tests','args':args,'status':r.returncode,'durationSeconds':time.monotonic()-begin});print(json.dumps(receipt['results'][-1]),flush=True)
if r.returncode==0:
 output=Path('/home/dek02/.cache/codex/tmp/product-host-legacy-ci-repair-oct14');assert not output.exists()
 args=[str(node),str(node.parent/'npm'),'run','build:product-host','--',str(output)];begin=time.monotonic()
 with (evidence/'ci-affinity-fresh-cli-26.11.1.log').open('x') as log:r=subprocess.run(args,cwd=host,env=env,stdout=log,stderr=subprocess.STDOUT)
 (evidence/'ci-affinity-fresh-cli-26.11.1.status').write_text(str(r.returncode)+'\n');receipt['results'].append({'stage':'standard fresh full build CLI','args':args,'status':r.returncode,'durationSeconds':time.monotonic()-begin,'output':str(output)});print(json.dumps(receipt['results'][-1]),flush=True)
(evidence/'ci-affinity-repair-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(r.returncode)

import {spawnSync} from 'node:child_process';import {writeFileSync,statSync} from 'node:fs';
const host='/home/dek02/.cache/codex/tmp/anyraid-moonraker-composition-integration/host',evidence='/home/dek02/.cache/codex/tmp/legacy-install-oct14',cache='/home/dek02/.codex/worktrees/e068/ANYRAID-KLIPPER/host/node_modules/.cache',node=evidence+'/node26.11.1/node-v26.11.1-linux-x64/bin/node';
const env={...process.env,TMPDIR:'/home/dek02/.cache/codex/tmp',CARGO:cache+'/cargo/bin/cargo',RUSTC:cache+'/cargo/bin/rustc',CARGO_HOME:cache+'/cargo',RUSTUP_HOME:cache+'/rustup',PATH:cache+'/cargo/bin:'+process.env.PATH,CARGO_BUILD_JOBS:'1'};
const files=['test/product-build.test.ts','test/product-native-build.test.ts'];
for(const f of files)statSync(host+'/'+f);
const result=spawnSync(node,['--test','--test-isolation=none','--test-concurrency=1','--test-reporter=tap',...files],{cwd:host,env,encoding:'utf8',maxBuffer:16*1024**2});
writeFileSync(evidence+'/ci-build-jobs1-repair-26.11.1.log',result.stdout+result.stderr,{flag:'wx'});writeFileSync(evidence+'/ci-build-jobs1-repair-26.11.1.status',String(result.status)+'\n',{flag:'wx'});console.log(JSON.stringify({node:process.version,files,status:result.status,error:result.error?.message,root:result.stdout.match(/# tests [\s\S]*$/)?.[0]}));process.exitCode=result.status??1;

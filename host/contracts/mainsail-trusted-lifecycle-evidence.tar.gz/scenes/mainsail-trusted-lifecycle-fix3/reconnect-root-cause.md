# fix3 断连证据更正

本场不是完整旅程通过。`013-ws-reconnected` 是操作方给出的错误标签；其 JSON 和截图实际均为 Connection failed / TRY AGAIN。原始文件保持不变。

固定 Mainsail v2.19.0、源码提交 `5fb9e77fb9f4e60cf0725d9dc7f57cf7b84bbd70`（只读检查 clean）：`webSocketClient.ts` 107–116 在 `e.wasClean` 或重试耗尽时调用 `socket/onClose` 后返回，仅非 clean 关闭安排自动重连；`socket-actions.ts` 43–45 进入 `setDisconnected`；`socket-mutations.ts` 20–24 设置 `connectingFailed=true`；`TheConnectingDialog.vue` 25、103–107 的原生 TRY AGAIN 按钮才调用 `connect()`。现场未直接记录浏览器 close.wasClean 值，故只说源码策略与实际失败对话框一致，不把该值当作已测证据。

实际固定资产 `assets/index-jNhnvCHe.js` 的 SHA256 为 `c8698c0bc6be76c897ae00865676b05e9aa4b833fc9b046f2d0c59692d60713b`，只读抽取确认同样的 `if(e.wasClean||this.reconnects>=this.maxReconnects) ... return` 分支。

实际 browser-ws-close 到失败页面观察为 17.350 秒，到 after-drop 断言为 17.535 秒。操作方没有先点击 TRY AGAIN，便过早要求第三条 WS，因此本场在该检查失败后收口。后续最小修正仅为页面动作顺序：保存真实断连观察，检查并点击可见 TRY AGAIN，随后在有界时间内等实际新 WS/握手与初始化，再执行原 after-drop 检查。结果应明确标为“断连后显式重连”，不能称自动重连通过。

打印中 reload 已核同一 job `000001`、同一 request、start 总数 1，进度由 0.127707 到 0.191608。断连后的只读 API 仍返回 printing、同 job/request、进度 0.383312、print_duration 78.671 秒；这保留为后台持续打印证据，不当作页面重连通过。

本场共159.072秒，首失败后清理错误为0。Windows owner、两SSH、专用Edge、watchdog共5个 PID 最终均不存在；Linux probe、watchdog、产品共3个 PID 均不存在；两watchdog remaining 均为空，19236/18434端口已释放。详见 receipt、windows-final-processes、linux-watchdog 和 reconnect-root-cause JSON。

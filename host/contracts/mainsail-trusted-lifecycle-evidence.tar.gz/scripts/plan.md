# Mainsail 1735 可信网络单次有限场

根 agent 已审查允许在现有项目隔离授权内启动这一次场景。默认只使用 Mainsail 2.19.0，固定候选 manifest 173565dc6b94d2d0380ec911f4f175d5a5b9f644880e8378245315eddf55e774，依赖 0b53079c853e4894141cf231e68b278c04de0db39fc26ea8e6326742f2e01fd4。产品、源码和既有证据不修改。

本次实际 IAB 初始化返回不可用；按用户 AGENTS 已授权后备方式，使用现有共享 Playwright 1.62.1、专用私有 Edge profile、默认浏览器 sandbox，不连接其他 profile。

## 生命周期与操作

1. 固定184的原 client-probe.ts --trusted-loopback 使用双PTY模拟MCU和独立实际产品子进程。remote probe18432经本机18434隧道提供原生Mainsail，不经JWT网关。启动仅API预置的client-sample文件排除于验收。
2. 无凭据GET/access/user必须返回_TRUSTED_USER_及三字段；浏览器HTTP与每次WS实际握手均只保存credential存在布尔值，禁止凭据请求。
3. 真实chooser上传本次独立长/短合成输入；由当时可见原生UI完成home与长任务开始。
4. 长任务printing时保存before-reload，原生浏览器reload，重连后保存after-reload；保持同history job_id与native_request_id、非倒退字节progress/print_duration、总起打仍1。
5. 保存before-drop，只向已核PID/startTicks的probe父进程发送一次SIGUSR2，记录实际1012关闭及新WS握手；after-drop复核同任务/进度/起打次数，之后才由页面Cancel并确认。
6. 只通过当前可见原生UI执行标准RESTART，记录printer.restart或RESTART脚本；禁止FirmwareRestart和SIGUSR1。产品PID/startTicks保持，设备generation增加。
7. 必要时页面重新home，再由页面明确开始另一短任务，最终history恰有长任务cancelled、不同短任务completed且各一次；不重放长任务。这里不重测旧下载、预览或SIGKILL。

## 单次owner与证据

owner.cjs为独立现有Node26.9进程，持有浏览器/PW/SSH生命周期，不依赖nodeREPL。out/commands/cmd-NNNN.json必须单调sequence，经原子rename为.consumed后只执行一次。每个UI动作要求最新observation编号，再核唯一、可见、enabled、viewport和剩余时限；用原生click/chooser/reload，不写DOM或Vue状态，不用API替代页面操作。观察与只读API保存到out/results及截图。

只读preload记录spawn/实际子进程PID、临时目录/upstream、ready及close1012，原参数/返回不变；ready校验失败明确记录并触发SIGTERM。产品自身仍使用原helper的无Python PATH与禁止TS实际JS子进程。

started由owner实际启动时唯一冻结；stopAt=started+780000，deadline=started+900000，不追加时限、不自动重开场。Windows与Linux独立watchdog最迟870s强制清理并留30s终态复核。Linux登记root提前退出时立即TERM已登记活子，5s后仍活则KILL。所有信号/终止复核PID及原startTicks；Edge再核专用profile/CDP。正常完成立即清理；首失败保留并有界收口，不再重启场景。

输出仅本场日志、只读状态、业务RPC方法/已批准合成文件名或Gcode、截图与精确收口记录。排除Edge profile、会话数据库、认证值和其他用户应用。字节进度与模拟运行时长不构成实机运动证明；本1735场不能倒写cd91旧A4包归属，也不关闭完整Moonraker/Python/宏、G3或物理门禁。

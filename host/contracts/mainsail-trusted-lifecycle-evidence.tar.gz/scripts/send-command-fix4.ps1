param([int]$Sequence,[string]$Op,[string]$Label,[int]$Observation=-1,[string]$Css,[string]$Role,[string]$Name,[string[]]$Files)
$ErrorActionPreference='Stop'
$scene=Join-Path (Get-Location) '.cache/client-fault-validation/mainsail-trusted-lifecycle-fix4'
$command=@{sequence=$Sequence;op=$Op;label=$Label}
if($Observation -ge 0){$command.observation=$Observation}
if($Css){$command.target=@{css=$Css}}
if($Role){$command.target=@{role=$Role;name=$Name;exact=$true}}
if($Files){$command.files=$Files}
$stem='cmd-'+$Sequence.ToString('0000')
$temporary=Join-Path $scene ('commands/'+$stem+'.tmp')
$destination=Join-Path $scene ('commands/'+$stem+'.json')
if(Test-Path ($destination+'.consumed')){throw 'Command already consumed'}
[IO.File]::WriteAllText($temporary,($command|ConvertTo-Json -Depth 6 -Compress),[Text.UTF8Encoding]::new($false))
Move-Item -LiteralPath $temporary -Destination $destination
$resultPath=Join-Path $scene ('results/'+$stem+'.json')
$until=[DateTime]::UtcNow.AddSeconds(15)
while(!(Test-Path $resultPath) -and !(Test-Path (Join-Path $scene 'receipt.json')) -and [DateTime]::UtcNow -lt $until){Start-Sleep -Milliseconds 100}
if(!(Test-Path $resultPath)){if(Test-Path (Join-Path $scene 'receipt.json')){Get-Content (Join-Path $scene 'receipt.json')};throw 'No successful owner command result'}
$result=Get-Content -Raw $resultPath|ConvertFrom-Json
if($result.result.id){@{id=$result.result.id;url=$result.result.url;body=$result.result.body;controls=@($result.result.controls|Where-Object{$_.name -or $_.title -or $_.aria})}|ConvertTo-Json -Depth 6 -Compress}
else{$result.result|ConvertTo-Json -Depth 20 -Compress}


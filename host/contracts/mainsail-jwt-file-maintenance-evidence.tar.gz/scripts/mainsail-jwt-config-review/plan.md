# 独立配置注释专场

- 原1735/0b53079c、Mainsail2.19.0、双PTY及JWT入口不变。仅配置补验，不上传/下载/预览/打印/队列/重启/故障，不给原N或N-diag补写成功。
- 固定输入是原28字节include行，加原预注册ASCII注释。首次现场及输入前均核对磁盘preimage；不匹配立即结束且不修改。
- 实际原生Machine→printer.cfg→观察编辑器。inspect_config保存完整工具栏DOM、各按钮SVG和CodeMirror可编辑DOM，核对固定TheEditor.vue的Save&Restart→save(null)图标→Close顺序，再inspect具体唯一图标后click。
- 自然点击.cm-content[contenteditable=true]，核对document.activeElement；Control+End后用只读DOM Range核对余下文本为空，再原生insertText仅追加既定注释。不触碰编辑器model/DOM赋值。
- 只点击Save图标（固定源save(null)）；禁止Save&Restart。等待并只读核对磁盘exact bytes后再Close，保存关闭截图；确认.cm-editor不存在后重新点printer.cfg，保存重开截图，核对可见注释及磁盘字节。
- Close与重开截图为必需；缺图保持部分结果，不称视读通过。first failure保留即时inventory/错误摘要并CLOSE清理。
- 原生操作前逐步inspect唯一/可见/启用；全程仅CLOSE stdin，780秒拒绝新动作、870秒守卫强制、900秒绝对截止不变。
- 独立本地及远端out：mainsail-jwt-config-once。Node语法及PowerShellparse先检查，根已许可在上述静态补充核对完成后启动唯一一次。

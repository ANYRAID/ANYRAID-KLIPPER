import {syncBuiltinESMExports,createRequire} from 'node:module';
import {readFile,writeFile,open} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {dirname} from 'node:path';
const base='/home/dek02/.codex/worktrees/supervisor-group-compat',out=base+'/evidence/mainsail-jwt-maintenance-once',runner=base+'/ANYRAID-KLIPPER/host/acceptance/client-fault-runner.ts',app=base+'/reserved-user-product',started=Number(process.env.ANYRAID_SCENE_STARTED),deadline=Number(process.env.ANYRAID_SCENE_DEADLINE),sha=b=>createHash('sha256').update(b).digest('hex');
if(process.argv[1]!==runner||process.argv[2]!=='mainsail'||process.argv[3]!=='/home/dek02/.cache/codex/tmp/anyraid-fixed-frontends/mainsail-2.19.0'||process.argv.length!==4||sha(await readFile(runner))!=='3ea68a718b2f2a4b813063913dcdccc0017f578c59708500b60d2f6af197cca2'||!Number.isSafeInteger(started)||deadline-started!==900000||Date.now()>=deadline-120000)throw Error('Frozen N runner/deadline mismatch');
const stat=await readFile('/proc/self/stat','utf8'),startTicks=stat.slice(stat.lastIndexOf(')')+2).split(' ')[19],native=createRequire(import.meta.url)('node:child_process'),spawn=native.spawn;
const log=await open(out+'/watchdog.log','wx'),watchdog=spawn(process.execPath,[out+'/linux-watchdog.mjs',String(process.pid),startTicks,String(deadline),out+'/watchdog.json'],{stdio:['ignore',log.fd,log.fd],detached:true});watchdog.unref();await log.close();
const launch={event:'bounded-scene-launch',pid:process.pid,startTicks,watchdogPid:watchdog.pid,started,deadline,stopNewActionsAt:deadline-120000,allowedStdin:['CLOSE']};await writeFile(out+'/running.json',JSON.stringify(launch,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(launch));
function reject(reason){console.log(JSON.stringify({event:'n-observation-rejected',reason}));process.kill(process.pid,'SIGTERM');}
native.spawn=function(command,args,options){
 const product=command===process.execPath&&args?.[0]===app+'/scripts/product-host.js',gateway=command===process.execPath&&args?.[0]===app+'/scripts/product-client.js';let profile,root;
 if(product){const at=args.indexOf('--profile');profile=args[at+1];root=dirname(profile??'');if(at<0||!root.startsWith('/tmp/anyraid-client-external-')||!profile.endsWith('/client-machine.mjs'))throw Error('Expected N isolated compiled profile');}
 const child=spawn.call(this,command,args,options);
 if(product||gateway){const role=product?'product':'gateway';void(async()=>{const raw=await readFile('/proc/'+child.pid+'/stat','utf8'),ticks=raw.slice(raw.lastIndexOf(')')+2).split(' ')[19],row={event:'n-'+role+'-spawn',pid:child.pid,startTicks:ticks,parent:process.pid,...product?{root,profile}:{}};await writeFile(out+'/'+role+'.json',JSON.stringify(row,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(row));})().catch(()=>reject(role+'-identity'));
  child.once('close',(code,signal)=>console.log(JSON.stringify({event:'n-'+role+'-close',pid:child.pid,code,signal})));
 }
 return child;
};syncBuiltinESMExports();

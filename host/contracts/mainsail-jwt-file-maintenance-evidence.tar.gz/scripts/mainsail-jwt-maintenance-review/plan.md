# N：1735 JWT 文件维护单次场

仅准备阶段。根已审owner边界并授权修正密码CSS/至少一次WS握手后开展一次场；不自动重开。固定173565dc产品、0b53079c依赖、Mainsail2.19.0、Node26.9、原双PTY。无打印、归位、队列、ARM/CRASH/RECOVER或设备控制；runner stdin只写CLOSE。后续打印队列/F场不在本准备内。

实际开始由owner唯一冻结started，780秒拒绝新动作并收口，870秒独立Windows/Linux watchdog精确身份强清理，900秒绝对期限；正常结束立即清理。沿用fix4的PID/startTicks字符串、Edge私有profile/CDP与root提前退出清理，不依赖REPL。首业务/断言失败保存并收口；只读inspect匹配0允许继续观察，截图失败单列，缺失预览图不得记通过。

1. 真gateway可见登录：runtime从固定合成fixture取账号，仅环境内存传owner，owner在任何子进程启动前删除环境；命令/日志不存凭据值。现场先inspect预注册 `input[name="username"]`／`input[name="password"]`，核INPUT name/type/同一form/submit后原生fill，实际点击登录。上下文只读GET核当前注册主体，至少一次真实WS握手才能完成。
2. 真实chooser一次上传944字节short和1000字节preview；原生表格可见文件名/大小/修改时间并只读API交叉核。单选short checkbox后header Download，Playwright默认所有权接opener/popup，failure=null、artifact与saveAs字节SHA一致。
3. preview精确文件名TD右键View3D；可见thumb中心点击自然聚焦，原生键盘每批最多5键到844/995，保存两张实际轨迹图。root须视读外框／内框，aria值不构成几何通过；preview永不打印。
4. 此后打开测试printer.cfg，任何编辑前只读核实际owned root下精确 `[include parts/machine.cfg]\n`。不符即无修改退出。Monaco普通点击自然聚焦→Control+End→仅预注册ASCII注释原生insertText；实际Save，不Save and restart。关闭/离开旧editor后原生重新打开printer.cfg，DOM可见注释，SSH只读原文件bytes必须恰为原内容+注释。
5. finish只读核identity、files、history为空；要求下载/两预览位置与图/Save重开精确字节/至少一WS，无任何打印或队列RPC。两图仅形成待根视读候选。截图缺失可保留部分结果，不能算该项通过。

命令单调序号原子消费，原生动作需当前observation内已inspect的目标；不得把依赖观察结果的动作盲接在同一工具调用。所有页面操作按当前实际DOM推进。页面HTTP/WS只存凭据存在布尔值，不存header/cookie/query值。只读API限固定GET，配置文件读取限本场已核root的config/printer.cfg。归档排除全部Edge profile、凭据/session数据库、运行环境与凭据值。

inputs.json只登记两文件和ASCII注释，sha由preflight.json冻结。当前准备未传输或启动任何新场，实际启动前再核两端固定文件及端口；不重建产品/native/依赖，不改生产源码。

const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto'),dir=__dirname,sha=b=>crypto.createHash('sha256').update(b).digest('hex');
let code=fs.readFileSync(path.join(dir,'../mainsail-trusted-lifecycle-review/owner-fix4.cjs'),'utf8');assert.equal(sha(Buffer.from(code)),'4ede60cbb72347e6eadea9d119a2ffdd9642c5f8630fee5bedcc5c7a125ad62b');
const part=name=>fs.readFileSync(path.join(dir,name),'utf8').trimEnd();
function between(start,end,value){const a=code.indexOf(start),b=code.indexOf(end,a+start.length);assert(a>=0&&b>a,start);code=code.slice(0,a)+value+'\n'+code.slice(b);}
code=code.replaceAll('mainsail-trusted-lifecycle-fix4','mainsail-jwt-maintenance-once').replaceAll('windows-watchdog-fix4.cjs','windows-watchdog.cjs');
const receiptLine=code.split('\n').find(l=>l.startsWith('const receipt='));assert(receiptLine);code=code.replace(receiptLine,"const receipt={started,deadline,stopNewActionsAt:stopAt,ownerPid:process.pid,node:process.version,scope:'N JWT file maintenance only; no print/queue/fault/device control',product:'173565dc6b94d2d0380ec911f4f175d5a5b9f644880e8378245315eddf55e774',dependencies:'0b53079c853e4894141cf231e68b278c04de0db39fc26ea8e6326742f2e01fd4',business:[],preview:[],loginFields:{username:false,password:false},websocketConnections:0,wsHandshakeChecked:0,steps:[],cleanupErrors:[],allowedStdin:['CLOSE']};");
code=code.replace("phase='setup';","phase='setup';let downloaded;");
between('const safe=s=>','function record(',"const safe=s=>{let value=String(s);if(loginPassword)value=value.replaceAll(loginPassword,'[synthetic-password-redacted]');return value.replace(/\\beyJ[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+\\b/g,'[jwt-redacted]').replace(/\\bBearer\\s+\\S+/gi,'[bearer-redacted]');};");
between('function requestClose()', 'async function freePort(',"function requestClose(){return closePromise??=(async()=>{if(!runner||runner.exitCode!==null||runner.signalCode!==null)return;record('explicit-CLOSE');await limited('CLOSE stdin',()=>new Promise((resolve,reject)=>{runner.stdin.write('CLOSE\\n',error=>{if(error)reject(error);else{runner.stdin.end();resolve();}});}),2000);})();}");
between('async function readJson(url)', 'const stopTimer=',part('n-helpers.cjs.part'));
between(' const cmd=', ' const argv=',part('n-setup.cjs.part'));
between(' const network=', ' while(!closing)',part('n-browser.cjs.part'));
between(' while(!closing)', ' }catch(error){receipt.status=',part('n-commands.cjs.part'));
code=code.replace("receipt.boundary='Same1735 package trusted raw Mainsail dualPTY lifecycle only; no real device, deployment, or oldcd91 UI relabeling';","receipt.boundary='Same1735 JWT gateway file maintenance only, dualPTY/no device operations; preview requires root visual audit; no oldcd91 relabeling';loginPassword=undefined;loginUsername=undefined;");
code=code.replaceAll("receipt.status!=='validated_candidate_for_root_audit'","receipt.status!=='validated_candidate_for_root_visual_audit'");
assert(!code.includes('drop_ws')&&!code.includes("command.op==='reload'")&&!code.includes('SIGUSR2')&&!code.includes('trusted-loopback'));
assert(!code.includes('[runtime-only-password-redacted]')&&!code.includes('mainsail-trusted-lifecycle-fix4'));
fs.writeFileSync(path.join(dir,'owner.cjs'),code,{flag:'wx'});
console.log(JSON.stringify({path:path.join(dir,'owner.cjs'),bytes:Buffer.byteLength(code),sha256:sha(Buffer.from(code))},null,2));

const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const code=fs.readFileSync(path.join(__dirname,'observer.cjs.part'),'utf8');
const {safeLocation,diagnosticText}=new Function('safe','loginUsername',code+';return {safeLocation,diagnosticText};')(s=>String(s).replaceAll('fixture-password-value','[redacted]'),'fixture-account');
const rows=[];
function check(name,fn){fn();rows.push({name,passed:true});}
check('URL userinfo query and fragment absent',()=>assert.deepEqual(safeLocation('http://fixture:fixture@127.0.0.1:18434/viewer?token=fixture#fixture'),{origin:'http://127.0.0.1:18434',path:'/viewer'}));
check('Non-network body omitted',()=>assert.deepEqual(safeLocation('data:text/html,fixture-password-value'),{origin:'data:',path:'[non-network-path-omitted]'}));
check('Console URL strips query fragment and userinfo',()=>assert.equal(diagnosticText('Failed http://fixture:fixture@127.0.0.1:18434/assets/viewer.js?fixture#fixture'),'Failed http://127.0.0.1:18434/assets/viewer.js'));
check('Credential field text omitted',()=>assert.equal(diagnosticText('token: fixture'),'[credential-bearing-text-redacted]'));
check('Known synthetic runtime account redacted',()=>assert(!diagnosticText('fixture-account fixture-password-value').includes('fixture-account')));
check('Unlabelled long value omitted',()=>assert.equal(diagnosticText('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'),'[long-value-redacted]'));
fs.writeFileSync(path.join(__dirname,'observer-static-check.json'),JSON.stringify({node:process.version,checks:rows,scope:'Pure safe metadata/redaction checks only; no browser or scenario started'},null,2)+'\n');
process.stdout.write(JSON.stringify({passed:rows.length})+'\n');

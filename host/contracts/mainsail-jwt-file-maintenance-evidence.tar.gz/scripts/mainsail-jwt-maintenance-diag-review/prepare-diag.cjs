const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const original=path.resolve(__dirname,'../mainsail-jwt-maintenance-review/owner.cjs');
if(crypto.createHash('sha256').update(fs.readFileSync(original)).digest('hex')!=='4c32e1db997ddc006b90f250c6d97c289ec8ff07659da6c10b3e3e21389c2947')throw Error('Original owner changed');
let owner=fs.readFileSync(original,'utf8');
function replace(before,after){if(owner.split(before).length!==2)throw Error('Patch anchor not unique: '+before.slice(0,80));owner=owner.replace(before,after);}
owner=owner.replaceAll('mainsail-jwt-maintenance-once','mainsail-jwt-maintenance-diag-once');
const oldSurface="function surface(spec={}){if(spec.surface==='page')return page;const f=page.frames().find(f=>f!==page.mainFrame()&&new URL(f.url()).host==='127.0.0.1:18434');if(!f)throw Error('Observed Mainsail frame absent');return f;}";
replace(oldSurface,fs.readFileSync(path.join(__dirname,'observer.cjs.part'),'utf8')+"\nfunction surface(spec={}){if(spec.surface==='page')return page;if(!selectedMainsailFrame||selectedMainsailFrame.isDetached())throw Error('Unique registered Mainsail iframe absent');return selectedMainsailFrame;}");
replace("const result={page:await collect(page)};try{result.mainsail=await collect(surface());}catch{}return result;","await refreshSurface();const result={page:await collect(page),browser:await inventory(label),diagnostics:diagnosticEvents.slice(-30)};if(selectedMainsailFrame)result.mainsail=await collect(surface());return result;");
replace("for(const p of context.pages())attach(p);context.on('page',p=>{record('context-page-added');attach(p);});","for(const p of context.pages()){attach(p);attachDiagnostics(p);}context.on('page',p=>{record('context-page-added',{pageId:pageId(p),...safeLocation(p.url())});attach(p);attachDiagnostics(p);void inventory('page-added').catch(error=>diagnostic('inventory-error',{name:error.name}));});");
replace("sequence++;let result;","sequence++;await refreshSurface();let result;");
replace("record('first-failure',receipt.error);if(page)","record('first-failure',receipt.error);if(context&&page)try{save('first-failure-browser.json',{browser:await limited('failure inventory',()=>inventory('first-failure'),1000),diagnostics:diagnosticEvents.slice(-30)});}catch{}if(page)");
fs.writeFileSync(path.join(__dirname,'owner.cjs'),owner);
for(const name of ['preload.mjs','windows-watchdog.cjs','start-owner.ps1','send-command.ps1']){
 let value=fs.readFileSync(path.resolve(__dirname,'../mainsail-jwt-maintenance-review',name),'utf8');
 value=value.replaceAll('mainsail-jwt-maintenance-once','mainsail-jwt-maintenance-diag-once').replaceAll('mainsail-jwt-maintenance-review','mainsail-jwt-maintenance-diag-review');
 if(name==='send-command.ps1')value=value.replace('screenshotCaptured=$result.result.screenshotCaptured','screenshotCaptured=$result.result.screenshotCaptured;browser=$result.result.browser;diagnostics=$result.result.diagnostics');
 fs.writeFileSync(path.join(__dirname,name),value);
}

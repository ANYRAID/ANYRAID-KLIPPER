# N-diag 单次隔离观察

- 固定1735/0b53079c产品、Mainsail2.19.0、原两输入哈希、JWT入口与双PTY不变；不打印、不队列、不注入故障，stdin仅CLOSE。
- 保持真实页面顺序：登录→chooser两文件→metadata→944字节原生下载→View3D→有界只读观察；不换顺序避开原异常。
- 新增安全origin/path、pageID/opener/frameparent与实际选中frameID、console/pageerror脱敏摘要、requestfailed及HTTP>=400状态/resourceType/path。不收headers、body、query/hash或console参数对象。
- 所有page均只观察。动作只落在当前JWT控制台唯一注册Mainsail iframe；标题、src=/、origin18434、直接parent均核对，歧义拒绝，不自动切换新页或遍历点击。若新页显示viewer，先读inventory并报告根审，不能沿旧iframe盲点。
- 预览正常时沿已审原N继续844/995两个真实键盘位置与截图，再仅ASCII配置注释Save/reopen/exact bytes；根必须视读两层截图。
- 首次可靠业务失败收集即时inventory/错误摘要后CLOSE清理；缺失截图单列且不称预览通过。不得自动重开。
- Windows/Linux各自独立900秒绝对截止；780秒拒绝新动作，870秒提前强制清理，正常结束立即清理并核对PID/startTicks、端口和两守卫终态。
- 独立本地/远端out均为mainsail-jwt-maintenance-diag-once；原mainsail-jwt-maintenance-once与launcher首失败不改动。本计划交根审后才启动。
